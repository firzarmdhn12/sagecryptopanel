<?php
require_once '../config/database.php';
require_once '../includes/api_response.php';

// Set headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');

// Fungsi untuk menghitung admin fee
function calculateAdminFee($amount, $type) {
    // Fee structure untuk CV Crypto
    $cryptoFeeStructure = [
        ['threshold' => 1000000, 'fee' => 5000],
        ['threshold' => 5000000, 'fee' => 10000],
        ['threshold' => 10000000, 'fee' => 15000],
        ['threshold' => 50000000, 'fee' => 25000],
        ['threshold' => PHP_FLOAT_MAX, 'fee' => 50000]
    ];

    // Fee structure untuk CV Exchange
    $exchangeFeeStructure = [
        ['threshold' => 1000000, 'fee' => 3000],
        ['threshold' => 5000000, 'fee' => 7000],
        ['threshold' => 10000000, 'fee' => 12000],
        ['threshold' => 50000000, 'fee' => 20000],
        ['threshold' => PHP_FLOAT_MAX, 'fee' => 35000]
    ];

    $feeStructure = $type === 'exchange' ? $exchangeFeeStructure : $cryptoFeeStructure;
    
    foreach ($feeStructure as $tier) {
        if ($amount <= $tier['threshold']) {
            return $tier['fee'];
        }
    }
    
    return $type === 'exchange' ? 35000 : 50000;
}

// Tambahkan fungsi untuk membersihkan estimated amount
function cleanEstimatedAmount($value) {
    // Hapus semua karakter kecuali angka
    $value = preg_replace('/[^0-9]/', '', $value);
    return $value;
}

try {
    // Debug: Log semua data yang diterima
    error_log("Received POST data: " . print_r($_POST, true));
    
    // Validasi field yang required berdasarkan tipe transaksi
    $type = $_POST['type'] ?? '';
    
    if ($type === 'crypto') {
        $required_fields = [
            'type',
            'amount',
            'estimated_amount',
            'coin',
            'network',
            'address',
            'bank_type',
            'account_number',
            'account_name'
        ];
    } else if ($type === 'exchange') {
        $required_fields = [
            'type',
            'amount',
            'estimated_amount',
            'exchange',
            'currency',
            'bank_type',
            'account_number',
            'account_name'
        ];
    } else {
        throw new Exception("Invalid transaction type");
    }

    foreach ($required_fields as $field) {
        if (!isset($_POST[$field]) || empty($_POST[$field])) {
            error_log("Missing field: " . $field);
            throw new Exception("Missing required field: " . $field);
        }
    }

    // Bersihkan nilai
    if ($type === 'crypto') {
        // Untuk crypto, amount bisa desimal
        $amount = str_replace([','], '.', $_POST['amount']); // Ganti koma dengan titik
        $amount = preg_replace('/[^0-9.]/', '', $amount); // Hapus karakter selain angka dan titik
    } else {
        // Untuk exchange, amount adalah nilai bulat
        $amount = preg_replace('/[^0-9]/', '', $_POST['amount']);
    }

    // Bersihkan estimated amount (selalu nilai bulat)
    $estimated_amount = cleanEstimatedAmount($_POST['estimated_amount']);

    // Debug log nilai setelah dibersihkan
    error_log("Cleaned values - Amount: $amount, Estimated: $estimated_amount");

    // Validasi nilai
    if (!is_numeric($amount) || !is_numeric($estimated_amount)) {
        throw new Exception('Invalid amount format');
    }

    // Hitung admin fee berdasarkan tipe
    $admin_fee = calculateAdminFee($estimated_amount, $type);
    $total_amount = $estimated_amount - $admin_fee;

    // Siapkan data transaksi dasar
    $transaction_data = [
        'type' => $type,
        'amount' => $amount,
        'estimated_amount' => $estimated_amount,
        'admin_fee' => $admin_fee,
        'total_amount' => $total_amount,
        'bank_type' => $_POST['bank_type'],
        'account_number' => $_POST['account_number'],
        'account_name' => $_POST['account_name'],
        'notes' => $_POST['notes'] ?? '',
        'status' => 'pending',
        'proof_image' => ''
    ];

    // Tambahkan data spesifik berdasarkan tipe
    if ($type === 'crypto') {
        $transaction_data = array_merge($transaction_data, [
            'coin' => $_POST['coin'],
            'network' => $_POST['network'],
            'tx_hash' => $_POST['tx_hash'],
            'address' => $_POST['address']
        ]);
    } else if ($type === 'exchange') {
        $transaction_data = array_merge($transaction_data, [
            'exchange' => $_POST['exchange'],
            'currency' => $_POST['currency']
        ]);
    }

    // Debug
    error_log("Transaction data to be saved: " . print_r($transaction_data, true));

    // Debug file upload
    error_log("Files received: " . print_r($_FILES, true));

    // Handle file upload
    if (!isset($_FILES['proof_image'])) {
        throw new Exception('Bukti transfer tidak ditemukan');
    }

    if ($_FILES['proof_image']['error'] !== UPLOAD_ERR_OK) {
        $uploadErrors = array(
            UPLOAD_ERR_INI_SIZE => 'File terlalu besar (melebihi upload_max_filesize)',
            UPLOAD_ERR_FORM_SIZE => 'File terlalu besar (melebihi MAX_FILE_SIZE)',
            UPLOAD_ERR_PARTIAL => 'File hanya terupload sebagian',
            UPLOAD_ERR_NO_FILE => 'Tidak ada file yang diupload',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
            UPLOAD_ERR_EXTENSION => 'File upload stopped by extension',
        );
        $errorMessage = isset($uploadErrors[$_FILES['proof_image']['error']]) 
            ? $uploadErrors[$_FILES['proof_image']['error']] 
            : 'Unknown upload error';
        throw new Exception('Error upload file: ' . $errorMessage);
    }

    // Validate and move file
    $file = $_FILES['proof_image'];
    $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
    $max_size = 2 * 1024 * 1024; // 2MB

    if (!in_array($file['type'], $allowed_types)) {
        throw new Exception('Format file tidak didukung. Gunakan JPG atau PNG');
    }

    if ($file['size'] > $max_size) {
        throw new Exception('Ukuran file maksimal 2MB');
    }

    // Create upload directory if not exists
    $upload_dir = __DIR__ . '/../uploads';
    if (!file_exists($upload_dir)) {
        if (!mkdir($upload_dir, 0755, true)) {
            throw new Exception('Gagal membuat direktori upload');
        }
    }

    // Generate unique filename
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid('proof_') . '.' . $ext;
    $upload_path = $upload_dir . '/' . $filename;

    if (!move_uploaded_file($file['tmp_name'], $upload_path)) {
        throw new Exception('Gagal memindahkan file');
    }

    // Add filename to transaction data
    $transaction_data['proof_image'] = $filename;

    // Debug final data
    error_log("Transaction data to be inserted: " . print_r($transaction_data, true));

    // Start transaction
    $db->beginTransaction();

    // Build query dinamis
    $columns = implode(", ", array_keys($transaction_data));
    $values = ":" . implode(", :", array_keys($transaction_data));
    
    $sql = "INSERT INTO transactions ($columns) VALUES ($values)";
    
    $stmt = $db->prepare($sql);
    
    if (!$stmt->execute($transaction_data)) {
        throw new Exception('Gagal menyimpan transaksi: ' . implode(", ", $stmt->errorInfo()));
    }

    $db->commit();

    sendResponse(true, 'Transaksi berhasil diproses', [
        'transaction_id' => $db->lastInsertId(),
        'amount' => $amount,
        'estimated_amount' => $estimated_amount,
        'admin_fee' => $admin_fee,
        'total_amount' => $total_amount
    ]);

} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }

    error_log("Transaction Error: " . $e->getMessage());
    sendResponse(false, $e->getMessage());
}

// Helper function to send JSON response
function sendResponse($success, $message, $data = []) {
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}
?>
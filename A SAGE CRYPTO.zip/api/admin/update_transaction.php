<?php
require_once '../../config/database.php';
require_once '../../includes/Transaction.php';
require_once '../../includes/api_response.php';
require_once '../../includes/admin_middleware.php';

// Verify admin authentication
requireAuth();

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['id']) || !isset($data['status'])) {
        throw new Exception('Transaction ID and status are required');
    }

    $transaction = new Transaction($db);
    $transaction->updateStatus($data['id'], $data['status']);

    ApiResponse::success(null, 'Transaction status updated successfully');
} catch (Exception $e) {
    ApiResponse::error($e->getMessage());
}
?>
<?php
require_once '../../config/admin.php';
require_once '../../includes/Auth.php';
require_once '../../includes/api_response.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ApiResponse::error('Invalid request method', 405);
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['username']) || !isset($data['password'])) {
    ApiResponse::error('Username and password are required');
}

$token = Auth::login($data['username'], $data['password']);

if ($token) {
    ApiResponse::success(['token' => $token]);
} else {
    ApiResponse::error('Invalid credentials', 401);
}
?>
<?php
require_once '../config/database.php';
require_once '../includes/Transaction.php';
require_once '../includes/api_response.php';

try {
    $transaction = new Transaction($db);
    $history = $transaction->getHistory();
    
    // Format data sebelum dikirim
    $formattedHistory = array_map(function($item) {
        return [
            'id' => $item['id'],
            'type' => $item['type'],
            'amount' => number_format($item['amount'], 2),
            'status' => $item['status'],
            'created_at' => date('d M Y H:i', strtotime($item['created_at'])),
            'details' => $item['type'] === 'crypto' ? [
                'coin' => $item['coin'],
                'network' => $item['network']
            ] : [
                'exchange' => $item['exchange'],
                'currency' => $item['currency']
            ]
        ];
    }, $history);

    ApiResponse::success($formattedHistory);
} catch (Exception $e) {
    ApiResponse::error($e->getMessage());
}
?>
<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Fungsi logging sederhana
function logError($message, $data = null) {
    $logMessage = date('[Y-m-d H:i:s] ') . $message;
    if ($data) {
        $logMessage .= ' Data: ' . json_encode($data);
    }
    error_log($logMessage . PHP_EOL, 3, __DIR__ . '/price_errors.log');
}

// Fungsi untuk mendapatkan harga dari Binance
function getBinancePrice($symbol) {
    try {
        $url = "https://api.binance.com/api/v3/ticker/price?symbol={$symbol}USDT";
        logError("Requesting Binance: " . $url);
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_TIMEOUT => 10
        ]);
        
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($error) {
            logError("Binance CURL Error: " . $error);
            return null;
        }

        if ($httpCode !== 200) {
            logError("Binance HTTP Error: " . $httpCode);
            return null;
        }

        $data = json_decode($response, true);
        logError("Binance Response: " . $response);

        if (isset($data['price'])) {
            return floatval($data['price']);
        }

        return null;
    } catch (Exception $e) {
        logError("Binance Exception: " . $e->getMessage());
        return null;
    }
}

// Fungsi untuk mendapatkan harga USDT/IDR dari Indodax
function getUsdtIdrPrice() {
    try {
        $url = "https://indodax.com/api/ticker/usdtidr";
        logError("Requesting Indodax: " . $url);
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_TIMEOUT => 10
        ]);
        
        $response = curl_exec($ch);
        curl_close($ch);

        if (!$response) {
            logError("No response from Indodax");
            return 15750; // Fallback price
        }

        $data = json_decode($response, true);
        if (isset($data['ticker']['last'])) {
            return floatval($data['ticker']['last']);
        }

        return 15750; // Fallback price
    } catch (Exception $e) {
        logError("Indodax Error: " . $e->getMessage());
        return 15750; // Fallback price
    }
}

// Get input
$symbol = isset($_GET['symbol']) ? strtoupper(trim($_GET['symbol'])) : '';

if (empty($symbol)) {
    echo json_encode([
        'success' => false,
        'message' => 'Symbol not provided'
    ]);
    exit;
}

try {
    $usdtIdrPrice = getUsdtIdrPrice();
    logError("USDT/IDR Price: " . $usdtIdrPrice);

    // Special case for USDT
    if ($symbol === 'USDT') {
        echo json_encode([
            'success' => true,
            'symbol' => 'USDT',
            'price_idr' => $usdtIdrPrice,
            'price_usdt' => 1,
            'usdt_idr' => $usdtIdrPrice,
            'last_updated' => date('Y-m-d H:i:s'),
            'source' => 'Indodax'
        ]);
        exit;
    }

    // Get price from Binance
    $price = getBinancePrice($symbol);
    
    // If price is null, use fallback price
    if ($price === null) {
        $fallbackPrices = [
            'CELO' => 0.5,
            'APT' => 8.5,
            'BTC' => 43000,
            'ETH' => 2200,
            // ... tambahkan koin lainnya
        ];

        if (!isset($fallbackPrices[$symbol])) {
            throw new Exception("No price available for $symbol");
        }

        $price = $fallbackPrices[$symbol];
        logError("Using fallback price for $symbol: $price");
    }

    echo json_encode([
        'success' => true,
        'symbol' => $symbol,
        'price_idr' => $price * $usdtIdrPrice,
        'price_usdt' => $price,
        'usdt_idr' => $usdtIdrPrice,
        'last_updated' => date('Y-m-d H:i:s'),
        'source' => $price === null ? 'Fallback' : 'Binance'
    ]);

} catch (Exception $e) {
    logError("Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

<?php
require_once '../config/database.php';
require_once '../includes/Transaction.php';
require_once '../includes/api_response.php';

try {
    if (!isset($_GET['id'])) {
        throw new Exception('Transaction ID is required');
    }

    $transaction = new Transaction($db);
    $detail = $transaction->getById($_GET['id']);
    
    if (!$detail) {
        throw new Exception('Transaction not found');
    }

    // Format detail transaksi
    $formattedDetail = [
        'id' => $detail['id'],
        'type' => $detail['type'],
        'amount' => number_format($detail['amount'], 2),
        'status' => $detail['status'],
        'bank_info' => [
            'type' => $detail['bank_type'],
            'account_number' => $detail['account_number'],
            'account_name' => $detail['account_name']
        ],
        'proof_image' => '/uploads/' . $detail['proof_image'],
        'created_at' => date('d M Y H:i', strtotime($detail['created_at'])),
        'details' => $detail['type'] === 'crypto' ? [
            'coin' => $detail['coin'],
            'network' => $detail['network'],
            'tx_hash' => $detail['tx_hash']
        ] : [
            'exchange' => $detail['exchange'],
            'currency' => $detail['currency']
        ]
    ];

    ApiResponse::success($formattedDetail);
} catch (Exception $e) {
    ApiResponse::error($e->getMessage());
}
?>
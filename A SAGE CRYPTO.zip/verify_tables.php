<?php
require_once 'config/database.php';

try {
    // Check tables
    $tables = ['settings', 'bank_accounts', 'transactions'];
    foreach($tables as $table) {
        $result = $db->query("SHOW TABLES LIKE '$table'");
        if($result->rowCount() > 0) {
            echo "Table '$table' exists<br>";
        } else {
            echo "Table '$table' does not exist<br>";
        }
    }
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
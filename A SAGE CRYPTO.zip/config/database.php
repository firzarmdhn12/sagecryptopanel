<?php
$host = 'localhost';
$dbname = 'sagd9981_sagecrypto';
$username = 'sagd9981_sagecrypto';
$password = 'frzaa163@@';

try {
    $db = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
    
    // Debug connection
    error_log("[Database] Connected successfully to $dbname");
    
    // Test query
    $test = $db->query("SELECT COUNT(*) as count FROM transactions");
    $count = $test->fetch()['count'];
    error_log("[Database] Found $count transactions in database");

} catch(PDOException $e) {
    error_log("[Database Error] Connection failed: " . $e->getMessage());
    die("Connection failed: " . $e->getMessage());
}

// Function to debug queries
function debugQuery($query, $params = []) {
    global $db;
    try {
        $stmt = $db->prepare($query);
        $stmt->execute($params);
        error_log("[Query Debug] Success: $query");
        error_log("[Query Params] " . json_encode($params));
        return $stmt;
    } catch(PDOException $e) {
        error_log("[Query Error] Failed: " . $e->getMessage());
        error_log("[Query Was] $query");
        error_log("[Query Params] " . json_encode($params));
        throw $e;
    }
}
?>
<?php
function logAdminActivity($adminId, $activityType, $description) {
    global $db;
    
    try {
        $sql = "INSERT INTO admin_activities (admin_id, activity_type, description, ip_address) 
                VALUES (:admin_id, :activity_type, :description, :ip_address)";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':admin_id' => $adminId,
            ':activity_type' => $activityType,
            ':description' => $description,
            ':ip_address' => $_SERVER['REMOTE_ADDR']
        ]);
        
        return true;
    } catch (Exception $e) {
        error_log("Error logging admin activity: " . $e->getMessage());
        return false;
    }
}

function getActivityTypeName($type) {
    $types = [
        'login' => 'Login',
        'logout' => 'Logout',
        'add_admin' => 'Tambah Admin',
        'edit_admin' => 'Edit Admin',
        'delete_admin' => 'Hapus Admin',
        'add_network' => 'Tambah Network',
        'edit_network' => 'Edit Network',
        'delete_network' => 'Hapus Network',
        'add_exchange' => 'Tambah Exchange',
        'edit_exchange' => 'Edit Exchange',
        'delete_exchange' => 'Hapus Exchange',
        'approve_order' => 'Approve Order',
        'cancel_order' => 'Cancel Order'
    ];
    
    return isset($types[$type]) ? $types[$type] : $type;
}
?>
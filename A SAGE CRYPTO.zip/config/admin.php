<?php
// Kredensial Admin
define('ADMIN_USERNAME', 'admin');  // Ganti dengan username yang Anda inginkan
define('ADMIN_PASSWORD_HASH', password_hash('admin123', PASSWORD_DEFAULT));  // Ganti dengan password yang Anda inginkan

// Pengaturan JWT
define('JWT_SECRET', 'SageRandomString123!@#');
define('JWT_EXPIRY', 3600);

// Pengaturan Upload
define('MAX_FILE_SIZE', 2 * 1024 * 1024);  // 2MB
define('ALLOWED_FILE_TYPES', ['image/jpeg', 'image/png']);
?>
<?php
// Path: public_html/config/config.php

// Base URL - Sesuaikan dengan domain Anda
$base_url = 'https://sagecrypto.id';

// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'sagd9981_sagecrypto');
define('DB_USER', 'sagd9981_sagecrypto');
define('DB_PASS', 'frzaa163@@');

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone
date_default_timezone_set('Asia/Jakarta');

// Session
session_start();
?>
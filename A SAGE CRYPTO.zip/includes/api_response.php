<?php
class ApiResponse {
    public static function success($data = null, $message = 'Success') {
        return self::send([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }

    public static function error($message = 'Error', $code = 400) {
        return self::send([
            'success' => false,
            'message' => $message
        ], $code);
    }

    private static function send($response, $code = 200) {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }
}
?>
<?php
class UploadHandler {
    private $uploadDir;
    private $maxFileSize = 2097152; // 2MB
    private $allowedTypes = ['image/jpeg', 'image/png'];

    public function __construct($uploadDir = '../uploads/') {
        $this->uploadDir = $uploadDir;
        if (!file_exists($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
    }

    public function handleUpload($file) {
        try {
            $this->validateUpload($file);
            $fileName = $this->generateFileName($file);
            $filePath = $this->uploadDir . $fileName;

            if (!move_uploaded_file($file['tmp_name'], $filePath)) {
                throw new Exception('Gagal mengupload file');
            }

            return $fileName;
        } catch (Exception $e) {
            throw new Exception('Upload error: ' . $e->getMessage());
        }
    }

    private function validateUpload($file) {
        if (!isset($file['error']) || is_array($file['error'])) {
            throw new Exception('Invalid file parameter');
        }

        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception($this->getUploadErrorMessage($file['error']));
        }

        if ($file['size'] > $this->maxFileSize) {
            throw new Exception('File terlalu besar (maksimal 2MB)');
        }

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if (!in_array($mimeType, $this->allowedTypes)) {
            throw new Exception('Tipe file tidak diizinkan (hanya JPG dan PNG)');
        }
    }

    private function generateFileName($file) {
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        return uniqid() . '_' . time() . '.' . $extension;
    }

    private function getUploadErrorMessage($error) {
        switch ($error) {
            case UPLOAD_ERR_INI_SIZE:
                return 'File melebihi batas ukuran upload di php.ini';
            case UPLOAD_ERR_FORM_SIZE:
                return 'File melebihi batas ukuran form';
            case UPLOAD_ERR_PARTIAL:
                return 'File hanya terupload sebagian';
            case UPLOAD_ERR_NO_FILE:
                return 'Tidak ada file yang diupload';
            case UPLOAD_ERR_NO_TMP_DIR:
                return 'Folder temporary tidak ditemukan';
            case UPLOAD_ERR_CANT_WRITE:
                return 'Gagal menulis file ke disk';
            case UPLOAD_ERR_EXTENSION:
                return 'Upload dihentikan oleh ekstensi PHP';
            default:
                return 'Unknown upload error';
        }
    }
}
?>
<?php
class Transaction {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function create($data) {
        try {
            $columns = implode(', ', array_keys($data));
            $values = ':' . implode(', :', array_keys($data));
            
            $sql = "INSERT INTO transactions ($columns, created_at) VALUES ($values, NOW())";
            $stmt = $this->db->prepare($sql);
            
            return $stmt->execute($data);
        } catch (PDOException $e) {
            throw new Exception('Failed to create transaction: ' . $e->getMessage());
        }
    }

    public function getHistory($limit = 10) {
        try {
            $sql = "SELECT * FROM transactions ORDER BY created_at DESC LIMIT :limit";
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            throw new Exception('Failed to get transaction history: ' . $e->getMessage());
        }
    }

    public function getById($id) {
        try {
            $sql = "SELECT * FROM transactions WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            throw new Exception('Failed to get transaction: ' . $e->getMessage());
        }
    }

    public function updateStatus($id, $status) {
        try {
            $sql = "UPDATE transactions SET status = :status, updated_at = NOW() WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([
                ':id' => $id,
                ':status' => $status
            ]);
        } catch (PDOException $e) {
            throw new Exception('Failed to update transaction status: ' . $e->getMessage());
        }
    }
}
?>
<?php
require_once '../vendor/autoload.php';
use \Firebase\JWT\JWT;

class Auth {
    private static function generateToken($username) {
        $issuedAt = time();
        $expiryTime = $issuedAt + JWT_EXPIRY;

        $payload = [
            'iss' => 'sagecrypto',
            'aud' => 'admin_panel',
            'iat' => $issuedAt,
            'exp' => $expiryTime,
            'username' => $username
        ];

        return JWT::encode($payload, JWT_SECRET, 'HS256');
    }

    public static function login($username, $password) {
        if ($username === ADMIN_USERNAME && 
            password_verify($password, ADMIN_PASSWORD_HASH)) {
            return self::generateToken($username);
        }
        return false;
    }

    public static function validateToken($token) {
        try {
            $decoded = JWT::decode($token, JWT_SECRET, ['HS256']);
            return $decoded->username === ADMIN_USERNAME;
        } catch (Exception $e) {
            return false;
        }
    }
}
?>
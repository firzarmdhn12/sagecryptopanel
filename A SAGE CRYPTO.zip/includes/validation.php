<?php
function validateAmount($amount) {
    if (!is_numeric($amount) || $amount <= 0) {
        throw new Exception('Invalid amount');
    }
    return floatval($amount);
}

function validateBankType($bankType) {
    $allowedBanks = ['bca', 'mandiri', 'bni', 'bri', 'other', 'ovo', 'gopay', 'dana', 'shopeepay'];
    if (!in_array($bankType, $allowedBanks)) {
        throw new Exception('Invalid bank type');
    }
    return $bankType;
}

function validateImage($file) {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('File upload failed');
    }

    $maxSize = 2 * 1024 * 1024; // 2MB
    if ($file['size'] > $maxSize) {
        throw new Exception('File size too large (max 2MB)');
    }

    $allowedTypes = ['image/jpeg', 'image/png'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mimeType, $allowedTypes)) {
        throw new Exception('Invalid file type (only JPG and PNG allowed)');
    }

    return true;
}
?>
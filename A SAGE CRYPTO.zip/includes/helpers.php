<?php
function generateUniqueFileName($originalName) {
    $extension = pathinfo($originalName, PATHINFO_EXTENSION);
    return uniqid() . '_' . time() . '.' . $extension;
}

function formatAmount($amount) {
    return number_format($amount, 2, ',', '.');
}

function getTransactionStatus($status) {
    $statusMap = [
        'pending' => 'Menunggu Verifikasi',
        'success' => 'Berhasil',
        'cancelled' => 'Dibatalkan'
    ];
    return $statusMap[$status] ?? 'Unknown';
}
?>
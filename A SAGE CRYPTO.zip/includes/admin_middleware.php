<?php
require_once 'Auth.php';

function requireAuth() {
    $headers = getallheaders();
    $token = isset($headers['Authorization']) ? 
        str_replace('Bearer ', '', $headers['Authorization']) : 
        null;

    if (!$token || !Auth::validateToken($token)) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }
}
?>
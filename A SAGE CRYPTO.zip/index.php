<!DOCTYPE html>
<html lang="id" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selamat Datang di SageCrypto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://api.fontshare.com/v2/css?f[]=cabinet-grotesk@1,800,500,700,400,300&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <style>
        :root[data-bs-theme="light"] {
            --primary-color: #34A4EB;
            --secondary-color: #10B981;
            --bg-color: #F0F4FF;
            --text-color: #1E293B;
            --card-bg: #FFFFFF;
            --navbar-bg: rgba(255, 255, 255, 0.95);
            --section-bg: #FFFFFF;
            --button-text: #FFFFFF;
            --select-text: #1E293B;
            --select-bg: #FFFFFF;
            --select-option-bg: #FFFFFF;
            --select-option-text: #1E293B;
            --select-option-hover: #F0F4FF;
        }
        
        :root[data-bs-theme="dark"] {
            --primary-color: #7B42F6;
            --secondary-color: #00FFB3;
            --bg-color: #0A0B1E;
            --text-color: #E6F0FF;
            --card-bg: #1A1B36;
            --navbar-bg: rgba(26, 27, 54, 0.95);
            --section-bg: #141528;
            --button-text: #000000;
            --select-text: #E6F0FF;
            --select-bg: #1A1B36;
            --select-option-bg: #1A1B36;
            --select-option-text: #E6F0FF;
            --select-option-hover: #2A2B4A;
        }
        
        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            font-family: 'Inter', sans-serif;
            transition: background-color 0.3s, color 0.3s;
        }

        h1, h2, h3, h4, h5, h6, .navbar-brand {
            font-family: 'Cabinet Grotesk', sans-serif;
        }

        .btn-custom {
            background-color: var(--secondary-color);
            color: var(--button-text);
            padding: 20px 30px;
            border-radius: 15px;
            border: 2px solid var(--secondary-color);
            transition: all 0.3s;
            font-size: 1.1rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            position: relative;
            overflow: hidden;
            z-index: 1;
            width: 100%;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(5px);
            box-shadow: 0 8px 32px rgba(0, 255, 179, 0.1);
        }
        
        .btn-custom:before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                120deg,
                transparent,
                rgba(255, 255, 255, 0.2),
                transparent
            );
            transition: 0.5s;
            z-index: -1;
        }
        
        .btn-custom:hover {
            background-color: transparent;
            color: var(--secondary-color);
            transform: scale(1.02);
            box-shadow: 0 8px 32px rgba(0, 255, 179, 0.2);
        }

        .btn-custom:hover:before {
            left: 100%;
        }

        .navbar {
            background-color: var(--navbar-bg);
            padding: 15px 0;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .navbar-toggler {
            border: none !important;
            padding: 0;
        }

        .navbar-nav {
            align-items: center;
            gap: 10px;
        }

        .nav-link {
            color: var(--text-color) !important;
            font-weight: 500;
            padding: 8px 16px !important;
        }

        .nav-link:hover {
            color: var(--secondary-color) !important;
        }

        .theme-switch-wrapper {
            display: flex;
            align-items: center;
            position: relative;
            margin-left: 15px;
        }

        .theme-switch {
            display: inline-block;
            width: 50px;
            height: 28px;
            position: relative;
        }

        .theme-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 28px;
        }

        .slider:before {
            position: absolute;
            content: "\f185";
            font-family: "Font Awesome 6 Free";
            font-weight: 900;
            height: 20px;
            width: 20px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            color: #5c5c5c;
        }

        input:checked + .slider:before {
            content: "\f186";
            transform: translateX(22px);
            color: #ffd700;
        }

        input:checked + .slider {
            background-color: var(--primary-color);
        }

        [data-bs-theme="light"] .navbar-dark {
            background-color: var(--navbar-bg);
        }

        [data-bs-theme="light"] .btn-custom {
            background-color: var(--primary-color);
            color: var(--button-text);
            border-color: var(--primary-color);
        }

        [data-bs-theme="light"] .btn-custom:hover {
            background-color: transparent;
            color: var(--primary-color);
        }

        [data-bs-theme="light"] .navbar-dark .navbar-brand,
        [data-bs-theme="light"] .navbar-dark .nav-link {
            color: var(--primary-color);
        }

        [data-bs-theme="light"] .nav-link {
            color: var(--primary-color) !important;
        }

        [data-bs-theme="light"] .navbar-toggler {
            border-color: var(--primary-color);
        }

        [data-bs-theme="light"] .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(52, 152, 219, 1)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }

        .deposit-form {
            background-color: var(--card-bg);
            border-radius: 15px;
            padding: 30px;
            margin-top: 100px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .loading-dots {
            display: inline-block;
        }

        .dot {
            display: inline-block;
            width: 8px;
            height: 8px;
            margin: 0 4px;
            background-color: var(--text-color);
            border-radius: 50%;
            opacity: 0.3;
            animation: pulse 1.4s infinite;
        }

        .dot:nth-child(2) {
            animation-delay: 0.2s;
        }

        .dot:nth-child(3) {
            animation-delay: 0.4s;
        }

        @keyframes pulse {
            0% { opacity: 0.3; }
            50% { opacity: 1; }
            100% { opacity: 0.3; }
        }
        
        #cryptoForm {
            display: none;
        }

        .title-with-back {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .title-with-back .btn-link {
            color: var(--text-color);
            text-decoration: none;
        }

        /* Choices.js Custom Styling */
        .choices {
            margin-bottom: 24px;
            font-size: 16px;
        }

        .choices__inner {
            background-color: var(--select-bg);
            border: 1px solid var(--dropdown-border);
            border-radius: 12px;
            min-height: 45px;
            padding: 6px 7.5px;
            color: var(--select-text);
        }

        .choices__list--single {
            padding: 4px 16px 4px 4px;
            color: var(--select-text);
        }

        .choices__list--dropdown {
            background-color: var(--select-option-bg);
            border: 1px solid var(--dropdown-border);
            border-radius: 0 0 12px 12px;
        }

        .choices__list--dropdown .choices__item--selectable {
            padding: 8px 16px !important;
            color: var(--select-option-text);
            border-bottom: 1px solid var(--dropdown-border);
            min-height: 40px;
            display: flex;
            align-items: center;
        }

        .choices__list--dropdown .choices__item--selectable.is-highlighted {
            background-color: var(--select-option-hover);
            color: var(--select-text);
        }

        .choices[data-type*="select-one"]:after {
            border-color: var(--text-color) transparent transparent transparent;
        }

        .choices[data-type*="select-one"].is-open:after {
            border-color: transparent transparent var(--text-color) transparent;
        }

        .choices__input {
            background-color: var(--select-bg);
            color: var(--select-text);
        }

        .choices__list--dropdown .choices__item {
            color: var(--select-option-text);
        }

        /* Form control colors */
        .form-control, 
        .form-select,
        .choices__inner {
            background-color: var(--select-bg);
            color: var(--select-text);
            border: 1px solid var(--dropdown-border) !important;
            width: 100%;
        }

        /* Light theme specific colors */
        [data-bs-theme="light"] {
            --select-bg: #ffffff;
            --select-text: #333333;
            --select-option-bg: #ffffff;
            --select-option-text: #333333;
            --dropdown-border: #dee2e6;
            --select-option-hover: #f8f9fa;
        }

        /* Dark theme specific colors */
        [data-bs-theme="dark"] {
            --select-bg: #2a2b4a;
            --select-text: #ffffff;
            --select-option-bg: #2a2b4a;
            --select-option-text: #ffffff;
            --dropdown-border: #404040;
            --select-option-hover: #3a3b5a;
        }

        /* Hover states */
        .choices__list--dropdown .choices__item--selectable.is-highlighted {
            background-color: var(--select-option-hover);
        }

        /* Focus states */
        .form-control:focus,
        .form-select:focus,
        .choices__inner:focus {
            border-color: var(--primary-color) !important;
            box-shadow: 0 0 0 0.25rem rgba(var(--primary-color-rgb), 0.25);
        }

        /* Option group styling */
        optgroup {
            color: var(--select-text);
            font-weight: 600;
            padding: 8px 16px !important;
        }

        option {
            color: var(--select-text);
            padding: 8px 16px !important;
            min-height: 40px;
            display: flex;
            align-items: center;
            width: 100% !important;
        }

        /* Choices.js inner styling */
        .choices__inner {
            min-height: 44px !important;
            padding: 4px 12px !important;
        }

        .choices__list--single {
            padding: 4px 16px 4px 4px !important;
            display: flex;
            align-items: center;
            min-height: 36px;
        }

        /* Dropdown list container */
        .choices__list--dropdown {
            margin-top: 2px;
        }

        /* Active/selected item */
        .choices__list--single .choices__item {
            display: flex;
            align-items: center;
        }

        /* Form text color */
        .form-text {
            color: var(--text-color);
        }

        /* Hide network selection by default */
        #networkContainer {
            display: none;
        }

        .price-details {
            padding: 10px;
            border-radius: 5px;
            background-color: rgba(0,0,0,0.02);
        }

        .total-price {
            font-size: 1.5em;
            font-weight: bold;
            color: #28a745;
        }

        .price-info {
            margin-top: 5px;
            font-size: 0.9em;
        }

        .loading-dots {
            color: #666;
        }

        .qr-container {
            background-color: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            display: inline-block;
            border: 1px solid var(--dropdown-border);
            margin: 0 auto;
        }

        .address-container {
            background-color: var(--card-bg);
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            border: 1px solid var(--dropdown-border);
        }

        .address-container .input-group {
            max-width: 500px;
            margin: 0 auto;
        }

        [data-bs-theme="dark"] .qr-container,
        [data-bs-theme="dark"] .address-container {
            background: #2a2b4a;
        }

        .transaction-details {
            background-color: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            border: 1px solid var(--dropdown-border);
        }

        .custom-file-upload {
            position: relative;
        }

        #imagePreview {
            background: var(--bg-color);
            padding: 10px;
            border-radius: 5px;
        }
        #exchangeImagePreview {
            background: var(--bg-color);
            padding: 10px;
            border-radius: 5px;
        }

        .loading-dots {
            display: inline-block;
        }

        .loading-dots .dot {
            display: inline-block;
            width: 8px;
            height: 8px;
            margin: 0 4px;
            border-radius: 50%;
            background-color: var(--text-color);
            animation: dot-pulse 1.4s infinite ease-in-out;
        }

        @keyframes dot-pulse {
            0%, 80%, 100% { transform: scale(0); }
            40% { transform: scale(1); }
        }

        .loading-dots .dot:nth-child(2) {
            animation-delay: 0.2s;
        }

        .loading-dots .dot:nth-child(3) {
            animation-delay: 0.4s;
        }

        .network-info-container {
            background-color: var(--card-bg);
            border: 1px solid var(--dropdown-border);
            border-radius: 10px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .network-info-container .qr-container {
            border: none;
            padding: 0;
            margin-bottom: 1.5rem;
            width: 100%;
        }

        .network-info-container .address-container {
            border: none;
            padding: 0;
            margin-bottom: 1.5rem;
            width: 100%;
        }

        .network-info-container .alert {
            margin-bottom: 1.5rem;
        }

        .network-info-container .btn-outline-primary {
            border-color: var(--primary-color);
            color: var(--primary-color);
        }

        .network-info-container .btn-outline-primary:hover {
            background-color: var(--primary-color);
            color: var(--button-text);
        }

        /* QR container styles */
        .qr-container {
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0 auto;
        }

        .qr-container img {
            max-width: 200px;
            height: auto;
            display: block;
            margin: 0 auto;
        }

        /* Form styling */
        .form-label {
            color: var(--text-color);
            margin-bottom: 0.75rem;
            display: flex;
            align-items: center;
        }

        .form-label i {
            color: var(--primary-color);
            width: 24px;
            font-size: 1.1rem;
        }

        .form-control-lg,
        .form-select-lg {
            font-size: 1rem;
            padding: 0.75rem 1rem;
            border-radius: 0.5rem;
        }

        .form-control::placeholder,
        .form-select::placeholder {
            color: var(--placeholder-color, #6c757d);
            opacity: 0.65;
        }

        .form-text {
            color: var(--text-muted, #6c757d);
            font-size: 0.875rem;
        }

        .price-details {
            background-color: var(--bg-color);
            border: 1px solid var(--dropdown-border);
            border-radius: 0.5rem;
            padding: 1rem;
        }

        .total-price {
            font-size: 1.1rem;
            font-weight: 500;
            color: var(--primary-color);
        }

        #imagePreview img {
            max-height: 200px;
            border: 1px solid var(--dropdown-border);
            border-radius: 0.5rem;
            padding: 0.5rem;
            background: var(--bg-color);
        }
        #exchangeImagePreview img {
            max-height: 200px;
            border: 1px solid var(--dropdown-border);
            border-radius: 0.5rem;
            padding: 0.5rem;
            background: var(--bg-color);
        }

        /* Button styling */
        .btn-success {
            font-size: 1rem;
            padding: 1rem 1.5rem;
            border-radius: 0.5rem;
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            padding: 12px 24px;
            font-weight: 500;
        }

        .btn-primary:hover {
            background-color: var(--primary-hover-color, #0056b3);
            border-color: var(--primary-hover-color, #0056b3);
        }

        .btn-primary:disabled {
            background-color: var(--primary-disabled-color, #6c757d);
            border-color: var(--primary-disabled-color, #6c757d);
            opacity: 0.65;
        }

        [data-bs-theme="dark"] .btn-primary {
            --primary-hover-color: #0056b3;
            --primary-disabled-color: #6c757d;
        }

        /* Input group styling */
        .input-group-lg {
            width: 100%;
        }

        .input-group-text {
            background-color: var(--bg-color);
            border-color: var(--dropdown-border);
            color: var(--primary-color);
            padding: 0.75rem;
            min-width: 45px;
            justify-content: center;
        }

        .input-group-text i {
            width: 20px;
            text-align: center;
            font-size: 1.1rem;
        }

        .form-text.text-danger {
            font-size: 0.875rem;
            color: #dc3545;
        }

        /* Form control and select styling */
        .form-control,
        .form-select,
        .choices__inner {
            font-size: 0.9rem !important;
        }

        /* Select element specific */
        select.form-select {
            width: 100%;
            padding-right: 2rem !important;
        }

        /* Placeholder color and size */
        .form-control::placeholder,
        .form-select::placeholder {
            color: var(--placeholder-color, #6c757d);
            opacity: 0.65;
            font-size: 0.9rem;
        }

        /* Input group focus state */
        .input-group:focus-within {
            box-shadow: 0 0 0 0.25rem rgba(var(--primary-color-rgb), 0.25);
        }

        .input-group:focus-within .input-group-text,
        .input-group:focus-within .form-control,
        .input-group:focus-within .form-select {
            border-color: var(--primary-color);
        }

        /* Option styling */
        option {
            font-size: 0.9rem;
            padding: 8px 16px !important;
        }

        optgroup {
            font-size: 0.9rem;
            padding: 8px 16px !important;
        }

        /* Form text and helper text */
        .form-text {
            color: var(--text-muted);
            font-size: 0.875rem;
            margin-top: 0.5rem;
        }

        /* Checkout container styling */
        .checkout-container {
            background-color: var(--card-bg);
            border: 1px solid var(--dropdown-border);
            border-radius: 10px;
            padding: 20px;
        }

        .checkout-item {
            font-size: 0.95rem;
            color: var(--text-color);
        }

        .checkout-item .fw-medium {
            color: var(--text-color);
        }

        .checkout-item .fw-bold {
            color: var(--text-color);
        }

        .checkout-item .text-primary {
            color: var(--primary-color) !important;
        }

        .checkout-item .text-danger {
            color: #dc3545 !important;
        }

        /* Icon styling */
        .checkout-container .fa-shopping-cart {
            color: var(--primary-color);
        }

        /* Choices.js dropdown input styling */
        .choices__list--dropdown .choices__input {
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-search' viewBox='0 0 16 16'%3E%3Cpath d='M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z'%3E%3C/path%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: 10px center;
            background-size: 16px;
            padding-left: 35px !important;
            margin: 0 !important;
            width: calc(100% - 20px) !important;
            border-bottom: 1px solid var(--dropdown-border) !important;
        }

        .choices__input {
            background-color: var(--select-bg) !important;
            color: var(--select-text) !important;
        }

        #bankSelect {
            width: 200%;
        }

        /* Choices.js Custom Styles */
        .choices {
            width: 100%;
        }
        
        .choices__inner {
            min-height: 48px;
            padding: 0.5rem 1rem;
            border-radius: 0 0.375rem 0.375rem 0 !important;
            border: 1px solid #ced4da;
            background-color: #fff;
        }

        .choices__list--single {
            padding: 2px 16px 2px 2px;
        }

        .choices__list--dropdown {
            z-index: 1000;
        }

        .choices-container .choices {
            margin-bottom: 0;
        }

        .input-group-lg .choices__inner {
            min-height: 48px;
            line-height: 1.5;
            font-size: 1rem;
        }

        .input-group > .choices:not(:first-child) .choices__inner {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;
        }

        .dark-theme .choices__inner,
        .dark-theme .choices__list--dropdown {
            background-color: #2b3035;
            border-color: #495057;
            color: #fff;
        }

        .dark-theme .choices__list--dropdown .choices__item {
            color: #fff;
        }

        .dark-theme .choices__list--dropdown .choices__item--selectable.is-highlighted {
            background-color: #495057;
        }

        /* Input Group Styles */
        .input-group .flex-grow-1 {
            position: relative;
        }

        .input-group .flex-grow-1 .choices {
            height: 100%;
        }

        .input-group .flex-grow-1 .choices__inner {
            height: 100%;
            border-radius: 0 0.375rem 0.375rem 0 !important;
            display: flex;
            align-items: center;
        }

        .input-group-text {
            display: flex;
            align-items: center;
        }

        .exchange-info-container {
            background-color: var(--card-bg);
            border: 1px solid var(--dropdown-border);
            border-radius: 10px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .exchange-logo-container {
            width: 120px;
            height: 120px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .exchange-logo-container img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        .exchange-info-container .address-container {
            width: 100%;
            margin-bottom: 1.5rem;
        }

        .exchange-info-container .form-label {
            font-weight: 500;
            margin-bottom: 0.5rem;
        }
        .exchange-info-container .exchange-name {
    margin-top: 0.5rem;
}

.exchange-info-container .form-control-plaintext {
    color: var(--text-color);
    padding: 0.5rem 0;
}

.spinner-border-sm {
    width: 1rem;
    height: 1rem;
    border-width: 0.2em;
}
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-chart-line me-2"></i>
                SageCrypto
            </a>
            <div class="d-flex align-items-center">
                <div class="theme-switch-wrapper me-3">
                    <label class="theme-switch">
                        <input type="checkbox" id="theme-toggle" checked>
                        <span class="slider"></span>
                    </label>
                </div>
            </div>
        </div>
    </nav>

    <!-- Deposit Form -->
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="deposit-form">
                    <!-- Initial Selection -->
                    <div class="mb-4" id="initialSelection">
                        <h4 class="fw-bold mb-4">Setoran CV Crypto</h4>
                        <div class="d-grid gap-3">
                            <button class="btn btn-custom" onclick="showCryptoForm()">
                                <i class="fas fa-coins me-2"></i>
                                CV Crypto
                            </button>
                            <button class="btn btn-custom" onclick="showExchangeForm()">
                                <i class="fas fa-exchange-alt me-2"></i>
                                CV Saldo Exchange
                            </button>
                        </div>
                    </div>

                    <!-- Crypto Form -->
                    <div id="cryptoForm" style="display: none;">
                    <div class="step" data-step="1">
                        <!-- Step 1: Crypto Selection -->
                        <div id="cryptoStep1">
                            <div class="title-with-back mb-4">
                                <button type="button" class="btn btn-link p-0" onclick="showInitialSelection()">
                                    <i class="fas fa-angle-left fs-4"></i>
                                </button>
                                <h4 class="mb-0 fw-bold">Pilih Crypto</h4>
                            </div>
                            
                            <div class="mb-3">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-coins"></i>
                                    </span>
                                    <div class="flex-grow-1">
                                        <select class="form-select" id="cryptoCoin" required>
                                            <option value="">Pilih crypto...</option>
                                            <option value="APT">Aptos (APT)</option>
                                            <option value="BNB">BNB</option>
                                            <option value="BTC">Bitcoin (BTC)</option>
                                            <option value="CELO">Celo (CELO)</option>
                                            <option value="CORE">Core DAO (CORE)</option>
                                            <option value="DOGE">Dogecoin (DOGE)</option>
                                            <option value="ETH">Ethereum (ETH)</option>
                                            <option value="FTM">Fantom (FTM)</option>
                                            <option value="MNT">Mantle (MNT)</option>
                                            <option value="MATIC">Polygon (MATIC)</option>
                                            <option value="NEAR">NEAR Protocol (NEAR)</option>
                                            <option value="SEI">Sei (SEI)</option>
                                            <option value="SOL">Solana (SOL)</option>
                                            <option value="SUI">Sui (SUI)</option>
                                            <option value="TON">TON Coin (TON)</option>
                                            <option value="TRX">TRON (TRX)</option>
                                            <option value="USDC">USD Coin (USDC)</option>
                                            <option value="USDT">Tether (USDT)</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3" id="networkContainer" style="display: none;">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-network-wired"></i>
                                    </span>
                                    <div class="flex-grow-1">
                                        <select class="form-select" id="network" required>
                                            <option value="">Pilih network...</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Network Info Container -->
                            <div class="network-info-container mt-4" style="display: none;">
                                <div class="qr-container mb-4">
                                    <img id="networkQR" src="" alt="QR Code" class="img-fluid">
                                </div>

                                <div class="address-container">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="networkAddress" readonly>
                                        <button class="btn btn-outline-primary" type="button" onclick="copyAddress()">
                                            <i class="fas fa-copy"></i>
                                        </button>
                                    </div>
                                </div>
                                <!-- Tambah memo di sini dengan style yang sama -->
                                <div class="address-container mt-3">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="networkMemo" readonly>
                                        <button class="btn btn-outline-primary" type="button" onclick="copyMemo()">
                                            <i class="fas fa-copy"></i>
                                        </button>
                                    </div>
                                </div>

                                <div class="alert alert-warning" role="alert">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    <strong>Penting:</strong> Pastikan network yang dipilih sesuai. Transaksi dengan network yang salah dapat menyebabkan kehilangan dana.
                                </div>
                            </div>


                            <div class="d-grid gap-2 mt-4">
                                <button type="button" id="confirmNetworkBtn" class="btn btn-primary btn-lg fw-medium" disabled onclick="showCryptoStep2()">
                                    <i class="fas fa-arrow-right me-2"></i>Lanjutkan
                                </button>
                            </div>
                        </div>
                    </div>

                        <!-- Step 2: Transaction Details -->
                        <div class="step" data-step="2">
                        <div id="cryptoStep2" style="display: none;">
                            <div class="title-with-back mb-4">
                                <button type="button" class="btn btn-link p-0" onclick="showCryptoStep1()">
                                    <i class="fas fa-angle-left fs-4"></i>
                                </button>
                                <h4 class="mb-0 fw-bold">Detail Transaksi</h4>
                            </div>

                            <!-- Selected Coin & Network Display -->
                            <div class="alert alert-primary d-flex align-items-center mb-4" role="alert">
                                <i class="fas fa-info-circle me-2"></i>
                                <div>
                                    Coin: <span id="selectedCoin" class="fw-bold"></span>
                                    <br>
                                    Network: <span id="selectedNetwork" class="fw-bold"></span>
                                </div>
                            </div>

                            <!-- Form Groups -->
                            <div class="mb-4">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-coins"></i>
                                    </span>
                                    <input type="number" 
       class="form-control" 
       id="amount" 
       placeholder="Masukkan jumlah" 
       step="0.00000001" 
       lang="en"
       inputmode="decimal"
       required>
                                </div>
                                <div class="price-details mt-2">
                                    <div class="total-price">
                                        Estimasi: <span id="priceEstimate">-</span>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-link"></i>
                                    </span>
                                    <input type="text" class="form-control" id="txHash" placeholder="Link TX Hash / Blockchain (Opsional)">
                                </div>
                                <div class="form-text text-danger">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Opsional: Masukkan link TX Hash atau Blockchain jika ada
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-image"></i>
                                    </span>
                                    <input type="file" class="form-control" id="proofImage" accept="image/*" required>
                                </div>
                                <div id="imagePreview" class="mt-3 text-center" style="display: none;">
                                    <img src="" alt="Preview" class="img-fluid rounded">
                                </div>
                                <div class="form-text mt-2">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Format yang diterima: JPG, PNG, JPEG (Maksimal 2MB)
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-university"></i>
                                    </span>
                                    <div class="flex-grow-1">
                                        <select class="form-select" id="bankSelect" required onchange="checkOtherBank()">
                                            <option value="">Pilih metode pembayaran</option>
                                            <optgroup label="Bank">
                                                <option value="bca">Bank Central Asia (BCA)</option>
                                                <option value="mandiri">Bank Mandiri</option>
                                                <option value="bni">Bank Negara Indonesia (BNI)</option>
                                                <option value="bri">Bank Rakyat Indonesia (BRI)</option>
                                                <option value="other">Bank Lain</option>
                                            </optgroup>
                                            <optgroup label="E-Wallet">
                                                <option value="ovo">OVO</option>
                                                <option value="gopay">GoPay</option>
                                                <option value="dana">DANA</option>
                                                <option value="shopeepay">ShopeePay</option>
                                            </optgroup>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Form Bank Lain -->
                            <div id="otherBankForm" class="mb-4" style="display: none;">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-building-columns"></i>
                                    </span>
                                    <input type="text" class="form-control" id="otherBankName" placeholder="Masukkan nama bank">
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-credit-card"></i>
                                    </span>
                                    <input type="number" class="form-control" id="accountNumber" placeholder="Masukkan nomor rekening" required>
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-user"></i>
                                    </span>
                                    <input type="text" class="form-control" id="accountName" placeholder="Masukkan nama lengkap sesuai rekening" required>
                                </div>
                            </div>

                            <!-- Container Detail Checkout -->
                            <div id="checkoutDetails" class="checkout-container mb-4" style="display: none;">
                                <div class="d-flex align-items-center mb-3">
                                    <i class="fas fa-shopping-cart fs-4 me-2 text-primary"></i>
                                    <h5 class="fw-bold mb-0">Detail Pembayaran</h5>
                                </div>
                                <div class="checkout-item d-flex justify-content-between mb-2">
                                    <span>Jumlah Transfer</span>
                                    <span id="checkoutAmount" class="fw-medium">-</span>
                                </div>
                                <div class="checkout-item d-flex justify-content-between mb-2">
                                    <span>Biaya Admin</span>
                                    <span id="checkoutFee" class="fw-medium text-danger">-</span>
                                </div>
                                <hr class="my-2">
                                <div class="checkout-item d-flex justify-content-between">
                                    <span class="fw-bold">Total Pembayaran</span>
                                    <span id="checkoutTotal" class="fw-bold text-primary">-</span>
                                </div>
                            </div>

                            <!-- Tombol Konfirmasi -->
                            <div class="d-grid gap-2 mt-4">
                                <button type="submit" id="confirmSentBtn" class="btn btn-success btn-lg fw-medium" disabled>
                                    <i class="fas fa-check me-2"></i>Konfirmasi Pengiriman
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                    <!-- Exchange Form -->
                    <div class="step" data-step="3">
                    <div id="exchangeForm" style="display: none;">
                        <!-- Step 1: Exchange Selection -->
                        <div id="exchangeStep1">
                            <div class="title-with-back mb-4">
                                <button type="button" class="btn btn-link p-0" onclick="showInitialSelection()">
                                    <i class="fas fa-angle-left fs-4"></i>
                                </button>
                                <h4 class="mb-0 fw-bold">Pilih Exchange</h4>
                            </div>
                            
                            <div class="mb-3">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-exchange-alt"></i>
                                    </span>
                                    <div class="flex-grow-1">
                                        <select class="form-select" id="exchangeSelect" required>
                                            <option value="">Pilih exchange...</option>
                                            <option value="binance">Binance</option>
                                            <option value="bybit">Bybit</option>
                                            <option value="okx">OKX</option>
                                            <option value="kucoin">KuCoin</option>
                                            <option value="mexc">MEXC</option>
                                            <option value="bitget">Bitget</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3" id="currencyContainer" style="display: none;">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-coins"></i>
                                    </span>
                                    <div class="flex-grow-1">
                                        <select class="form-select" id="currency" required>
                                            <option value="">Pilih currency...</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

<!-- Exchange Info Container -->
<div class="exchange-info-container mt-4" style="display: none;">
    <div class="exchange-logo-container mb-4">
        <img id="exchangeLogo" src="" alt="Exchange Logo" class="img-fluid">
    </div>
        <label class="form-label">Kirim ke:</label>
        <div class="input-group mb-3">
            <input type="text" class="form-control" id="exchangeAddress" readonly>
            <button class="btn btn-outline-primary" type="button" onclick="copyExchangeAddress()">
                <i class="fas fa-copy"></i>
            </button>
        </div>
        <div class="exchange-name">
            <label class="form-label">Atas Nama:</label>
            <div class="form-control" id="exchangeName">-</div>
                        </div>

                            <div class="alert alert-warning mt-3" role="alert">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                <strong>Penting:</strong> Pastikan ID/Email tujuan sudah benar sebelum melakukan transfer.
    </div>
</div>

                            <div class="d-grid gap-2 mt-4">
                                <button type="button" id="confirmExchangeBtn" class="btn btn-primary btn-lg fw-medium" disabled onclick="showExchangeStep2()">
                                    <i class="fas fa-arrow-right me-2"></i>Lanjutkan
                                </button>
                            </div>
                        </div>
                    </div>

                        <!-- Step 2: Exchange Transaction Details -->
                        <div id="exchangeStep2" style="display: none;">
                            <div class="title-with-back mb-4">
                                <button type="button" class="btn btn-link p-0" onclick="showExchangeStep1()">
                                    <i class="fas fa-angle-left fs-4"></i>
                                </button>
                                <h4 class="mb-0 fw-bold">Detail Transaksi</h4>
                            </div>

                            <!-- Selected Exchange & Currency Display -->
                            <div class="alert alert-primary d-flex align-items-center mb-4" role="alert">
                                <i class="fas fa-info-circle me-2"></i>
                                <div>
                                    Exchange: <span id="selectedExchange" class="fw-bold"></span>
                                    <br>
                                    Currency: <span id="selectedCurrency" class="fw-bold"></span>
                                </div>
                            </div>

                            <!-- Form Groups -->
                            <div class="mb-4">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-coins"></i>
                                    </span>
                                    <input type="number" class="form-control" id="exchangeAmount" placeholder="Jumlah yang akan dikirim" step="0.00000001" required>
                                </div>
                                <div class="price-details mt-2">
                                    <div class="total-price">
                                        Estimasi: <span id="exchangePriceEstimate">-</span>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-image"></i>
                                    </span>
                                    <input type="file" class="form-control" id="exchangeProofImage" accept="image/*" required>
                                </div>
                                <div id="exchangeImagePreview" class="mt-3 text-center" style="display: none;">
                                    <img src="" alt="Preview" class="img-fluid rounded">
                                </div>
                                <div class="form-text mt-2">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Format yang diterima: JPG, PNG, JPEG (Maksimal 2MB)
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-university"></i>
                                    </span>
                                    <div class="flex-grow-1">
                                        <select class="form-select" id="exchangeBankSelect" required onchange="checkExchangeOtherBank()">
                                            <option value="">Pilih metode pembayaran</option>
                                            <optgroup label="Bank">
                                                <option value="bca">Bank Central Asia (BCA)</option>
                                                <option value="mandiri">Bank Mandiri</option>
                                                <option value="bni">Bank Negara Indonesia (BNI)</option>
                                                <option value="bri">Bank Rakyat Indonesia (BRI)</option>
                                                <option value="other">Bank Lain</option>
                                            </optgroup>
                                            <optgroup label="E-Wallet">
                                                <option value="ovo">OVO</option>
                                                <option value="gopay">GoPay</option>
                                                <option value="dana">DANA</option>
                                                <option value="shopeepay">ShopeePay</option>
                                            </optgroup>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Form Bank Lain -->
                            <div id="exchangeOtherBankForm" class="mb-4" style="display: none;">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-building-columns"></i>
                                    </span>
                                    <input type="text" class="form-control" id="exchangeOtherBankName" placeholder="Masukkan nama bank">
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-credit-card"></i>
                                    </span>
                                    <input type="number" class="form-control" id="exchangeAccountNumber" placeholder="Masukkan nomor rekening" required>
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="input-group input-group-lg">
                                    <span class="input-group-text">
                                        <i class="fas fa-user"></i>
                                    </span>
                                    <input type="text" class="form-control" id="exchangeAccountName" placeholder="Masukkan nama lengkap sesuai rekening" required>
                                </div>
                            </div>

                            <!-- Container Detail Checkout -->
                            <div id="exchangeCheckoutDetails" class="checkout-container mb-4" style="display: none;">
                                <div class="d-flex align-items-center mb-3">
                                    <i class="fas fa-shopping-cart fs-4 me-2 text-primary"></i>
                                    <h5 class="fw-bold mb-0">Detail Pembayaran</h5>
                                </div>
                                <div class="checkout-item d-flex justify-content-between mb-2">
                                    <span>Jumlah Transfer</span>
                                    <span id="exchangeCheckoutAmount" class="fw-medium">-</span>
                                </div>
                                <div class="checkout-item d-flex justify-content-between mb-2">
                                    <span>Biaya Admin</span>
                                    <span id="exchangeCheckoutFee" class="fw-medium text-danger">-</span>
                                </div>
                                <hr class="my-2">
                                <div class="checkout-item d-flex justify-content-between">
                                    <span class="fw-bold">Total Pembayaran</span>
                                    <span id="exchangeCheckoutTotal" class="fw-bold text-primary">-</span>
                                </div>
                            </div>

                            <!-- Tombol Konfirmasi -->
                            <div class="d-grid gap-2 mt-4">
                                <button type="submit" id="exchangeConfirmSentBtn" class="btn btn-success btn-lg fw-medium" disabled>
                                    <i class="fas fa-check me-2"></i>Konfirmasi Pengiriman
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tambahkan setelah container CV -->
    <div class="container py-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">History Transaksi Terakhir</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID Transaksi</th>
                                <th>Status</th>
                                <th>Nominal</th>
                                <th>Tanggal</th>
                            </tr>
                        </thead>
                        <tbody id="transactionHistory">
                            <!-- Data will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/choices.js/public/assets/scripts/choices.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
// Global variables and configurations
const networkOptions = {
    'APT': ['Aptos Network'],
    'BNB': ['BNB Beacon Chain (BEP2)', 'BNB Smart Chain (BEP20)'],
    'BTC': ['Bitcoin Network (BTC)', 'Lightning Network'],
    'CELO': ['Celo Network'],
    'CORE': ['Core Network'],
    'DOGE': ['Dogecoin Network'],
    'ETH': ['Ethereum Network (ERC20)', 'Arbitrum One', 'Optimism'],
    'FTM': ['Fantom Network'],
    'MNT': ['Mantle Network'],
    'MATIC': ['Polygon Network'],
    'NEAR': ['NEAR Protocol (NEAR)'],
    'SEI': ['Sei (SEI)'],
    'SOL': ['Solana Network'],
    'SUI': ['Sui Network'],
    'TON': ['TON Network'],
    'TRX': ['TRON Network'],
    'USDC': ['Ethereum Network (ERC20)', 'Solana Network', 'BNB Smart Chain (BEP20)'],
    'USDT': ['Ethereum Network (ERC20)', 'Tron Network (TRC20)', 'BNB Smart Chain (BEP20)']
};

const exchangeCurrencies = {
    'binance': ['USDT', 'BUSD', 'BNB'],
    'bybit': ['USDT', 'USDC'],
    'okx': ['USDT', 'USDC'],
    'kucoin': ['USDT', 'USDC'],
    'mexc': ['USDT', 'USDC'],
    'bitget': ['USDT', 'USDC']
};

// Tambahkan data exchange
const exchangeDetails = {
    'binance': {
        logo: 'assets/images/exchanges/binance.png',
        address: 'deposit@binance.com',
        name: 'PT Binance Exchange Indonesia'
    },
    'bybit': {
        logo: 'assets/images/exchanges/bybit.png',
        address: 'deposit@bybit.com',
        name: 'PT Bybit Exchanger'
    },
    'okx': {
        logo: 'assets/images/exchanges/okx.png',
        address: 'deposit@okx.com',
        name: 'PT OKX Indonesia'
    },
    'kucoin': {
        logo: 'assets/images/exchanges/kucoin.png',
        address: 'deposit@kucoin.com',
        name: 'PT KuCoin Global'
    },
    'mexc': {
        logo: 'assets/images/exchanges/mexc.png',
        address: 'deposit@mexc.com',
        name: 'PT MEXC Trading'
    },
    'bitget': {
        logo: 'assets/images/exchanges/bitget.png',
        address: 'deposit@bitget.com',
        name: 'PT Bitget Indonesia'
    }
};

// Initialize Choices.js instances
let coinChoices;
let networkChoices;
let exchangeChoices;
let currencyChoices;
let bankChoices;
let exchangeBankChoices;

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    initializeChoices();
    setupEventListeners();
    setupThemeToggle();
    setupExchangeFormValidation();
    loadTransactionHistory();
    const coinSelect = document.getElementById('cryptoCoin');
    const amountInput = document.getElementById('amount');
    const selectedCoinSpan = document.getElementById('selectedCoin');
        // Fungsi update placeholder
        function updateAmountPlaceholder() {
        const selectedCoin = coinSelect.value;
        if (selectedCoin) {
            amountInput.placeholder = `Jumlah ${selectedCoin} yang Dikirim`;
            selectedCoinSpan.textContent = selectedCoin;
        } else {
            amountInput.placeholder = 'Pilih koin terlebih dahulu';
            selectedCoinSpan.textContent = '-';
        }
        console.log('Updated placeholder:', amountInput.placeholder); // Debug
    }

    // Event listener untuk perubahan coin
    coinSelect.addEventListener('change', function() {
        updateAmountPlaceholder();
        if (this.value) {
            updatePrice(this.value);
        }
    });

    // Update placeholder saat halaman dimuat
    updateAmountPlaceholder();
});

// Initialize Choices.js
function initializeChoices() {
    const choicesConfig = {
        searchEnabled: true,
        itemSelectText: '',
        shouldSort: false,
        position: 'bottom',
        searchPlaceholderValue: 'Cari disini...'
    };

    // Crypto coin select
    const cryptoCoin = document.getElementById('cryptoCoin');
    if (cryptoCoin) {
        coinChoices = new Choices(cryptoCoin, {
            ...choicesConfig,
            placeholderValue: 'Pilih crypto...',
            choices: [{ value: '', label: 'Pilih crypto...', disabled: true }]
        });
    }

    // Network select
    const network = document.getElementById('network');
    if (network) {
        networkChoices = new Choices(network, {
            ...choicesConfig,
            placeholderValue: 'Pilih jaringan...',
            choices: [{ value: '', label: 'Pilih jaringan...', disabled: true }]
        });
    }

    // Exchange select
    const exchangeSelect = document.getElementById('exchangeSelect');
    if (exchangeSelect) {
        exchangeChoices = new Choices(exchangeSelect, {
            ...choicesConfig,
            placeholderValue: 'Pilih exchange...',
            choices: [{ value: '', label: 'Pilih exchange...', disabled: true }]
        });
    }

    // Currency select
    const currencySelect = document.getElementById('currency');
    if (currencySelect) {
        currencyChoices = new Choices(currencySelect, {
            ...choicesConfig,
            placeholderValue: 'Pilih mata uang...',
            choices: [{ value: '', label: 'Pilih mata uang...', disabled: true }]
        });
    }

    // Bank select untuk Crypto
    const bankSelect = document.getElementById('bankSelect');
    if (bankSelect) {
        bankChoices = new Choices(bankSelect, {
            ...choicesConfig,
            searchPlaceholderValue: 'Cari metode pembayaran...'
        });
    }

    // Bank select untuk Exchange
    const exchangeBankSelect = document.getElementById('exchangeBankSelect');
    if (exchangeBankSelect) {
        exchangeBankChoices = new Choices(exchangeBankSelect, {
            ...choicesConfig,
            searchPlaceholderValue: 'Cari metode pembayaran...'
        });
    }
}

// Setup Event Listeners
function setupEventListeners() {
    // Crypto form events
    document.getElementById('cryptoCoin')?.addEventListener('change', handleCryptoChange);
    document.getElementById('network')?.addEventListener('change', handleNetworkChange);
    document.getElementById('amount')?.addEventListener('input', debounce(updateCheckoutDetails, 500));
    document.getElementById('amount')?.addEventListener('blur', updateCheckoutDetails);
    // Tambahkan ini di bagian script
document.getElementById('amount').addEventListener('keydown', function(e) {
    // Jika user menekan koma, ganti dengan titik
    if (e.key === ',') {
        e.preventDefault();
        this.value += '.';
    }
});

document.getElementById('amount').addEventListener('input', function(e) {
    // Ganti semua koma dengan titik
    let newValue = this.value.replace(/,/g, '.');
    
    // Jika nilai berubah karena penggantian koma
    if (newValue !== this.value) {
        this.value = newValue;
        
        // Mempertahankan posisi kursor
        const cursorPos = this.selectionStart;
        this.setSelectionRange(cursorPos, cursorPos);
    }
});

// Mencegah paste dengan koma
document.getElementById('amount').addEventListener('paste', function(e) {
    e.preventDefault();
    const pastedText = (e.clipboardData || window.clipboardData).getData('text');
    const newValue = pastedText.replace(/,/g, '.');
    
    // Insert nilai yang sudah dibersihkan pada posisi kursor
    const cursorPos = this.selectionStart;
    this.value = this.value.slice(0, cursorPos) + newValue + this.value.slice(this.selectionEnd);
    
    // Update posisi kursor
    const newCursorPos = cursorPos + newValue.length;
    this.setSelectionRange(newCursorPos, newCursorPos);
});
    document.getElementById('proofImage')?.addEventListener('change', handleImageUpload);
    
    // Exchange form events
    document.getElementById('exchangeSelect')?.addEventListener('change', handleExchangeChange);
    document.getElementById('currency')?.addEventListener('change', handleCurrencyChange);
    document.getElementById('exchangeAmount')?.addEventListener('input', debounce(updateExchangeCheckoutDetails, 500));
    document.getElementById('exchangeAmount')?.addEventListener('blur', updateExchangeCheckoutDetails);
    document.getElementById('exchangeProofImage')?.addEventListener('change', handleExchangeImageUpload);
    
    // Form validation events
    const formInputs = [
        'bankSelect', 'otherBankName', 'accountNumber', 'accountName',
        'exchangeBankSelect', 'exchangeOtherBankName', 'exchangeAccountNumber', 'exchangeAccountName'
    ];
    
    formInputs.forEach(id => {
        document.getElementById(id)?.addEventListener('input', validateForm);
        document.getElementById(id)?.addEventListener('change', validateForm);
    });
}

// Theme Toggle
function setupThemeToggle() {
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        // Set initial state based on saved preference or default
        const currentTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-bs-theme', currentTheme);
        themeToggle.checked = currentTheme === 'dark';

        themeToggle.addEventListener('change', function() {
            const newTheme = this.checked ? 'dark' : 'light';
            document.documentElement.setAttribute('data-bs-theme', newTheme);
            localStorage.setItem('theme', newTheme);
        });
    }
}

// Navigation Functions
function showInitialSelection() {
    // Reset all forms and containers
    resetForms();
    
    // Show initial selection
    document.getElementById('initialSelection').style.display = 'block';
    document.getElementById('cryptoForm').style.display = 'none';
    document.getElementById('exchangeForm').style.display = 'none';
}

function showCryptoForm() {
    document.getElementById('initialSelection').style.display = 'none';
    document.getElementById('cryptoForm').style.display = 'block';
    document.getElementById('cryptoStep1').style.display = 'block';
    document.getElementById('cryptoStep2').style.display = 'none';
    resetCryptoForm();
}

function showExchangeForm() {
    document.getElementById('initialSelection').style.display = 'none';
    document.getElementById('cryptoForm').style.display = 'none';
    document.getElementById('exchangeForm').style.display = 'block';
    document.getElementById('exchangeStep1').style.display = 'block';
    document.getElementById('exchangeStep2').style.display = 'none';
    resetExchangeForm();
}

function showCryptoStep1() {
    // Reset step 2
    resetCryptoStep2();
    
    // Reset network info if going back
    document.querySelector('.network-info-container').style.display = 'none';
    document.getElementById('networkQR').src = '';
    document.getElementById('networkAddress').value = '';
    
    // Show step 1
    document.getElementById('cryptoStep1').style.display = 'block';
    document.getElementById('cryptoStep2').style.display = 'none';
}

function showCryptoStep2() {
    const coinValue = document.getElementById('cryptoCoin').value;
    const networkValue = document.getElementById('network').value;
    
    if (!coinValue || !networkValue) {
        alert('Silakan pilih crypto dan network terlebih dahulu');
        return;
    }
    
    // Update selected coin and network display
    document.getElementById('selectedCoin').textContent = coinValue;
    document.getElementById('selectedNetwork').textContent = networkValue;
    
    // Update network details (QR and address)
    updateNetworkDetails(coinValue, networkValue);
    
    document.getElementById('cryptoStep1').style.display = 'none';
    document.getElementById('cryptoStep2').style.display = 'block';
}

function showExchangeStep1() {
    // Reset step 2
    resetExchangeStep2();
    
    // Reset exchange info if going back
    document.querySelector('.exchange-info-container').style.display = 'none';
    document.getElementById('exchangeLogo').src = '';
    document.getElementById('exchangeAddress').value = '';
    document.getElementById('exchangeName').textContent = '-';
    
    // Show step 1
    document.getElementById('exchangeStep1').style.display = 'block';
    document.getElementById('exchangeStep2').style.display = 'none';
}

function showExchangeStep2() {
    const exchangeValue = document.getElementById('exchangeSelect').value;
    const currencyValue = document.getElementById('currency').value;
    
    if (!exchangeValue || !currencyValue) {
        alert('Silakan pilih exchange dan currency terlebih dahulu');
        return;
    }
    
    // Update selected exchange and currency display
    document.getElementById('selectedExchange').textContent = exchangeValue.toUpperCase();
    document.getElementById('selectedCurrency').textContent = currencyValue;
    
    document.getElementById('exchangeStep1').style.display = 'none';
    document.getElementById('exchangeStep2').style.display = 'block';
}

// Handle Form Changes
function handleCryptoChange(event) {
    const selectedCoin = event.target.value;
    const networkContainer = document.getElementById('networkContainer');
    const networkInfoContainer = document.querySelector('.network-info-container');
    const confirmNetworkBtn = document.getElementById('confirmNetworkBtn');
    
    // Reset network selection completely
    networkChoices.clearStore();
    networkChoices.clearChoices();
    networkChoices.setChoices([
        { value: '', label: 'Pilih jaringan...', disabled: true }
    ]);
    
    // Hide and reset network info
    networkContainer.style.display = 'none';
    networkInfoContainer.style.display = 'none';
    document.getElementById('networkQR').src = '';
    document.getElementById('networkAddress').value = '';
    
    if (selectedCoin) {
        // Show network container
        networkContainer.style.display = 'block';
        
        // Update network options
        const networks = networkOptions[selectedCoin] || [];
        const networkChoicesArray = [
            { value: '', label: 'Pilih jaringan...', disabled: true },
            ...networks.map(network => ({
                value: network,
                label: network
            }))
        ];
        
        // Update network select with new choices
        networkChoices.setChoices(networkChoicesArray, 'value', 'label', true);
    }
    
    // Always disable continue button when coin changes
    confirmNetworkBtn.disabled = true;
}

function handleNetworkChange(event) {
    const networkValue = event.target.value;
    const confirmNetworkBtn = document.getElementById('confirmNetworkBtn');
    const networkInfoContainer = document.querySelector('.network-info-container');
    
    if (networkValue) {
        // Show network info container
        networkInfoContainer.style.display = 'block';
        // Update network details
        const coinValue = document.getElementById('cryptoCoin').value;
        updateNetworkDetails(coinValue, networkValue);
        // Enable continue button
        confirmNetworkBtn.disabled = false;
    } else {
        // Hide network info container
        networkInfoContainer.style.display = 'none';
        confirmNetworkBtn.disabled = true;
    }
}
function handleExchangeChange(event) {
    const selectedExchange = event.target.value;
    const currencyContainer = document.getElementById('currencyContainer');
    const exchangeInfoContainer = document.querySelector('.exchange-info-container');
    const confirmExchangeBtn = document.getElementById('confirmExchangeBtn');
    
    // Reset currency selection
    currencyChoices.clearStore();
    currencyChoices.clearChoices();
    currencyChoices.setChoices([
        { value: '', label: 'Pilih mata uang...', disabled: true }
    ]);
    
    // Hide and reset exchange info
    currencyContainer.style.display = 'none';
    exchangeInfoContainer.style.display = 'none';
    
    if (selectedExchange && exchangeCurrencies[selectedExchange]) {
        // Show currency container
        currencyContainer.style.display = 'block';
        
        // Update currency options
        const currencies = exchangeCurrencies[selectedExchange];
        const currencyChoicesArray = [
            { value: '', label: 'Pilih mata uang...', disabled: true },
            ...currencies.map(currency => ({
                value: currency,
                label: currency
            }))
        ];
        
        // Update currency select with new choices
        currencyChoices.setChoices(currencyChoicesArray, 'value', 'label', true);
    }
    
    // Always disable continue button when exchange changes
    confirmExchangeBtn.disabled = true;
}

function handleCurrencyChange() {
    const exchangeValue = document.getElementById('exchangeSelect').value;
    const currencyValue = document.getElementById('currency').value;
    const confirmExchangeBtn = document.getElementById('confirmExchangeBtn');
    const exchangeInfoContainer = document.querySelector('.exchange-info-container');
    
    if (exchangeValue && currencyValue) {
        // Show exchange info container and update details
        exchangeInfoContainer.style.display = 'block';
        if (exchangeDetails[exchangeValue]) {
            document.getElementById('exchangeLogo').src = exchangeDetails[exchangeValue].logo;
            document.getElementById('exchangeAddress').value = exchangeDetails[exchangeValue].address;
            document.getElementById('exchangeName').textContent = exchangeDetails[exchangeValue].name;
        }
        confirmExchangeBtn.disabled = false;
    } else {
        exchangeInfoContainer.style.display = 'none';
        confirmExchangeBtn.disabled = true;
    }
}

// Image Upload Handlers
function handleImageUpload(event) {
    const file = event.target.files[0];
    const preview = document.getElementById('imagePreview');
    const previewImg = preview.querySelector('img');
    
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    } else {
        preview.style.display = 'none';
    }
    
    validateForm();
}

function handleExchangeImageUpload(event) {
    const file = event.target.files[0];
    const preview = document.getElementById('exchangeImagePreview');
    const previewImg = preview.querySelector('img') || document.createElement('img');
    
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            if (!preview.querySelector('img')) {
                preview.appendChild(previewImg);
            }
            preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    } else {
        preview.style.display = 'none';
    }
    
    validateExchangeForm();
}

// Loading dots management
function showLoadingDots(elementId) {
    const element = document.getElementById(elementId);
    element.innerHTML = `
        <span class="loading-dots">
            <span class="dot"></span>
            <span class="dot"></span>
            <span class="dot"></span>
        </span>
    `;
}

function hideLoadingDots(elementId, text) {
    const element = document.getElementById(elementId);
    element.textContent = text;
}

// Price Update Functions
async function updateCheckoutDetails() {
    const amountElement = document.getElementById('amount');
    const checkoutDetails = document.getElementById('checkoutDetails');
    const selectedCoin = document.getElementById('cryptoCoin').value;
    const priceEstimate = document.getElementById('priceEstimate');

    if (!amountElement?.value || !selectedCoin) {
        checkoutDetails.style.display = 'none';
        priceEstimate.textContent = '-';
        return;
    }

    const amount = parseFloat(amountElement.value);
    if (isNaN(amount) || amount <= 0) {
        checkoutDetails.style.display = 'none';
        priceEstimate.textContent = '-';
        return;
    }

    // Show loading dots
    showLoadingDots('priceEstimate');

    try {
        const response = await fetch(`api/price_handler.php?symbol=${selectedCoin}`);
        const data = await response.json();

        if (data.success) {
            const estimatedIDR = amount * parseFloat(data.price_idr);
            const adminFee = calculateAdminFee(estimatedIDR, 'crypto');
            const total = estimatedIDR - adminFee;

            // Hide loading dots and update price estimate
            hideLoadingDots('priceEstimate', formatRupiah(estimatedIDR));

            // Update checkout details
            document.getElementById('checkoutAmount').textContent = formatRupiah(estimatedIDR);
            document.getElementById('checkoutFee').textContent = `- ${formatRupiah(adminFee)}`;
            document.getElementById('checkoutTotal').textContent = formatRupiah(total);
            checkoutDetails.style.display = 'block';

            validateForm();
        }
    } catch (error) {
        console.error('Error:', error);
        hideLoadingDots('priceEstimate', 'Error getting price');
        checkoutDetails.style.display = 'none';
    }
}

async function updateExchangeCheckoutDetails() {
    const amountElement = document.getElementById('exchangeAmount');
    const checkoutDetails = document.getElementById('exchangeCheckoutDetails');
    const selectedCurrency = document.getElementById('currency').value;
    const priceEstimate = document.getElementById('exchangePriceEstimate');

    if (!amountElement?.value || !selectedCurrency) {
        checkoutDetails.style.display = 'none';
        priceEstimate.textContent = '-';
        return;
    }

    const amount = parseFloat(amountElement.value);
    if (isNaN(amount) || amount <= 0) {
        checkoutDetails.style.display = 'none';
        priceEstimate.textContent = '-';
        return;
    }

    showLoadingDots('exchangePriceEstimate');

    try {
        const response = await fetch(`api/price_handler.php?symbol=${selectedCurrency}`);
        const data = await response.json();

        if (data.success) {
            const estimatedIDR = amount * parseFloat(data.price_idr);
            const adminFee = calculateAdminFee(estimatedIDR, 'exchange');
            const total = estimatedIDR - adminFee;

            hideLoadingDots('exchangePriceEstimate', formatRupiah(estimatedIDR));

            document.getElementById('exchangeCheckoutAmount').textContent = formatRupiah(estimatedIDR);
            document.getElementById('exchangeCheckoutFee').textContent = `- ${formatRupiah(adminFee)}`;
            document.getElementById('exchangeCheckoutTotal').textContent = formatRupiah(total);
            checkoutDetails.style.display = 'block';

            // Trigger validation after updating checkout details
            validateExchangeForm();
        }
    } catch (error) {
        console.error('Error:', error);
        hideLoadingDots('exchangePriceEstimate', 'Error getting price');
        checkoutDetails.style.display = 'none';
    }
}

// Form Validation Functions
function validateForm() {
    const amount = document.getElementById('amount')?.value;
    const proofImage = document.getElementById('proofImage')?.value;
    const bankSelect = document.getElementById('bankSelect')?.value;
    const accountNumber = document.getElementById('accountNumber')?.value;
    const accountName = document.getElementById('accountName')?.value;
    const otherBankName = document.getElementById('otherBankName')?.value;
    
    const isOtherBank = bankSelect === 'other';
    const isValidOtherBank = !isOtherBank || (isOtherBank && otherBankName);
    
    const confirmBtn = document.getElementById('confirmSentBtn');
    confirmBtn.disabled = !(
        amount && 
        proofImage && 
        bankSelect && 
        accountNumber && 
        accountName && 
        isValidOtherBank
    );
}

function validateExchangeForm() {
    try {
        // Get all required form values
        const amount = document.getElementById('exchangeAmount')?.value;
        const proofImage = document.getElementById('exchangeProofImage')?.files[0]; // Changed to check files
        const bankSelect = document.getElementById('exchangeBankSelect')?.value;
        const accountNumber = document.getElementById('exchangeAccountNumber')?.value;
        const accountName = document.getElementById('exchangeAccountName')?.value;
        const otherBankName = document.getElementById('exchangeOtherBankName')?.value;
        
        // Get the confirm button
        const confirmBtn = document.getElementById('exchangeConfirmSentBtn');
        
        // Check if bank is 'other' and requires additional validation
        const isOtherBank = bankSelect === 'other';
        const isValidOtherBank = !isOtherBank || (isOtherBank && otherBankName);
        
        // Debug logs
        console.log('Exchange Form Validation:', {
            amount,
            hasProofImage: !!proofImage,
            bankSelect,
            accountNumber,
            accountName,
            otherBankName,
            isOtherBank,
            isValidOtherBank
        });
        
        // Validate all required fields
        const isValid = !!(
            amount && 
            proofImage && 
            bankSelect && 
            accountNumber && 
            accountName && 
            isValidOtherBank
        );
        
        // Enable/disable button based on validation
        if (confirmBtn) {
            confirmBtn.disabled = !isValid;
        }
        
        return isValid;
    } catch (error) {
        console.error('Error in validateExchangeForm:', error);
        return false;
    }
}

// Bank Form Handlers
function checkOtherBank() {
    const bankValue = bankChoices.getValue().value;
    const otherBankForm = document.getElementById('otherBankForm');
    
    if (bankValue === 'other') {
        otherBankForm.style.display = 'block';
    } else {
        otherBankForm.style.display = 'none';
        document.getElementById('otherBankName').value = '';
    }
    
    validateForm();
}

function checkExchangeOtherBank() {
    const bankValue = exchangeBankChoices.getValue().value;
    const otherBankForm = document.getElementById('exchangeOtherBankForm');
    
    if (bankValue === 'other') {
        otherBankForm.style.display = 'block';
    } else {
        otherBankForm.style.display = 'none';
        document.getElementById('exchangeOtherBankName').value = '';
    }
    
    validateExchangeForm();
}

// Reset Functions
function resetForms() {
    resetCryptoForm();
    resetExchangeForm();
}

function resetCryptoForm() {
    // Reset selections
    coinChoices?.setChoiceByValue('');
    networkChoices?.clearStore();
    networkChoices?.setChoices([
        { value: '', label: 'Pilih network...', disabled: true }
    ]);
    
    // Reset containers visibility
    document.getElementById('networkContainer').style.display = 'none';
    document.querySelector('.network-info-container').style.display = 'none';
    
    // Reset network details
    document.getElementById('networkQR').src = '';
    document.getElementById('networkAddress').value = '';
    
    // Reset button state
    document.getElementById('confirmNetworkBtn').disabled = true;
    
    resetCryptoStep2();
}

function resetCryptoStep2() {
    const elements = [
        'amount',
        'proofImage',
        'txHash',  // Tambahkan ini
        'otherBankName',
        'accountNumber',
        'accountName'
    ];
    
    elements.forEach(id => {
        const element = document.getElementById(id);
        if (element) element.value = '';
    });

    // Reset bank select dengan Choices.js
    bankChoices?.setChoiceByValue('');

    document.getElementById('imagePreview').style.display = 'none';
    document.getElementById('checkoutDetails').style.display = 'none';
    document.getElementById('otherBankForm').style.display = 'none';
    document.getElementById('confirmSentBtn').disabled = true;
}

function resetExchangeForm() {
    // Reset selections
    exchangeChoices?.setChoiceByValue('');
    currencyChoices?.clearStore();
    currencyChoices?.setChoices([
        { value: '', label: 'Pilih currency...', disabled: true }
    ]);
    
    // Reset containers visibility
    document.getElementById('currencyContainer').style.display = 'none';
    document.querySelector('.exchange-info-container').style.display = 'none';
    
    // Reset exchange details
    document.getElementById('exchangeLogo').src = '';
    document.getElementById('exchangeAddress').value = '';
    document.getElementById('exchangeName').textContent = '-';
    
    // Reset button state
    document.getElementById('confirmExchangeBtn').disabled = true;
    
    resetExchangeStep2();
}

function resetExchangeStep2() {
    const elements = [
        'exchangeAmount',
        'exchangeProofImage',
        'exchangeOtherBankName',
        'exchangeAccountNumber',
        'exchangeAccountName'
    ];
    
    elements.forEach(id => {
        const element = document.getElementById(id);
        if (element) element.value = '';
    });

    // Reset bank select dengan Choices.js
    exchangeBankChoices?.setChoiceByValue('');

    document.getElementById('exchangeImagePreview').style.display = 'none';
    document.getElementById('exchangeCheckoutDetails').style.display = 'none';
    document.getElementById('exchangeOtherBankForm').style.display = 'none';
    document.getElementById('exchangeConfirmSentBtn').disabled = true;
}

// Utility Functions
function debounce(func, wait) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

function formatRupiah(number) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0  // Tambahkan ini untuk memastikan tidak ada desimal
    }).format(number);
}

// Update input amount untuk menerima desimal
async function updateEstimateDisplay() {
    try {
        const amount = document.getElementById('amount').value;  // Untuk crypto, tetap bisa desimal
        const selectedCoin = document.getElementById('cryptoCoin').value;
        const priceEstimate = document.getElementById('priceEstimate');
        const checkoutAmount = document.getElementById('checkoutAmount');
        
        if (!amount || !selectedCoin || !priceEstimate) {
            if (priceEstimate) priceEstimate.textContent = '-';
            if (checkoutAmount) checkoutAmount.textContent = '-';
            return;
        }

        // Show loading
        priceEstimate.innerHTML = `<span class="spinner-border spinner-border-sm"></span>`;

        // Fetch price from API
        const response = await fetch(`api/price_handler.php?symbol=${selectedCoin}`);
        const data = await response.json();

        if (data.success) {
            // Hitung estimasi dan bulatkan ke bawah (floor) untuk menghilangkan desimal
            const estimatedIDR = Math.floor(parseFloat(amount) * parseFloat(data.price_idr));
            
            // Update both displays with the same value
            const formattedEstimate = formatRupiah(estimatedIDR);
            priceEstimate.textContent = formattedEstimate;
            if (checkoutAmount) {
                checkoutAmount.textContent = formattedEstimate;
            }

            // Update admin fee dan total
            const adminFee = calculateAdminFee(estimatedIDR, 'crypto');
            const totalAmount = estimatedIDR - adminFee;

            // Update tampilan fee dan total
            document.getElementById('checkoutFee').textContent = formatRupiah(adminFee);
            document.getElementById('checkoutTotal').textContent = formatRupiah(totalAmount);

            // Debug
            console.log('Estimate updated:', {
                amount,
                price: data.price_idr,
                estimatedIDR,
                formattedValue: formattedEstimate,
                adminFee,
                totalAmount
            });
        }

    } catch (error) {
        console.error('Error updating estimate:', error);
        if (priceEstimate) priceEstimate.textContent = 'Error';
    }
}

// Fungsi untuk format Rupiah
function formatRupiah(number) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
    }).format(number);
}

// Update fungsi submitCryptoTransaction
async function submitCryptoTransaction() {
    try {
        // Validasi elemen form
        const formElements = {
            amount: document.getElementById('amount'),
            coin: document.getElementById('cryptoCoin'),
            network: document.getElementById('network'),
            address: document.getElementById('networkAddress'),
            memo: document.getElementById('networkMemo'),
            txHash: document.getElementById('txHash'),
            bankSelect: document.getElementById('bankSelect'),
            otherBankName: document.getElementById('otherBankName'), // Tambah element bank lain
            accountNumber: document.getElementById('accountNumber'),
            accountName: document.getElementById('accountName'),
            estimatePrice: document.getElementById('checkoutAmount')
        };

        // Debug: Log elemen form
        console.log('Form elements:', formElements);

        // Validasi elemen yang required
        for (const [key, element] of Object.entries(formElements)) {
            if (!element) {
                throw new Error(`Element not found: ${key}`);
            }
        }

        // Disable button dan tampilkan loading
        const submitButton = document.getElementById('confirmSentBtn');
        if (!submitButton) throw new Error('Submit button not found');
        
        submitButton.disabled = true;
        submitButton.innerHTML = `
            <span class="spinner-border spinner-border-sm me-2"></span>
            Memproses...
        `;

        // Tentukan bank_type berdasarkan pilihan user
        let bankType;
        if (formElements.bankSelect.value === 'other') {
            if (!formElements.otherBankName.value.trim()) {
                throw new Error('Mohon masukkan nama bank');
            }
            bankType = formElements.otherBankName.value.trim();
            console.log('Using other bank name:', bankType);
        } else {
            bankType = formElements.bankSelect.value;
            console.log('Using selected bank:', bankType);
        }

        // Kumpulkan data form
        const formData = new FormData();
        
        // File handling
        const proofFile = document.getElementById('proofImage').files[0];
        if (!proofFile) {
            throw new Error('Bukti transfer wajib diupload');
        }
        
        // Debug file
        console.log('File to upload:', proofFile);
        
        formData.append('proof_image', proofFile);
        formData.append('type', 'crypto');
        formData.append('amount', formElements.amount.value);
        formData.append('coin', formElements.coin.value);
        formData.append('network', formElements.network.value);
        formData.append('address', formElements.address.value);
        formData.append('memo', formElements.memo.value);
        formData.append('tx_hash', formElements.txHash.value);
        formData.append('bank_type', bankType); // Gunakan bankType yang sudah ditentukan
        formData.append('account_number', formElements.accountNumber.value);
        formData.append('account_name', formElements.accountName.value);
        
        // Ambil nilai estimasi dan hapus format Rupiah dan desimal
        let estimatedAmount = document.getElementById('checkoutAmount').textContent;
        estimatedAmount = estimatedAmount.replace(/[^0-9,]/g, '');
        estimatedAmount = estimatedAmount.split(',')[0];
        formData.append('estimated_amount', estimatedAmount);

        // Debug: Log form data
        for (let pair of formData.entries()) {
            console.log(pair[0] + ': ' + pair[1]);
        }

        // Kirim request ke server
        const response = await fetch('api/process_transaction.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        console.log('Server response:', result);

        if (result.success) {
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Transaksi crypto Anda telah berhasil diproses.',
                allowOutsideClick: false,
                allowEscapeKey: false,
                confirmButtonText: 'OK'
            }).then(() => {
                window.location.reload();
            });
        } else {
            throw new Error(result.message || 'Terjadi kesalahan saat memproses transaksi.');
        }

    } catch (error) {
        console.error('Error submitting crypto transaction:', error);
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: error.message || 'Terjadi kesalahan saat memproses transaksi.',
            confirmButtonText: 'OK'
        });
    } finally {
        const submitButton = document.getElementById('confirmSentBtn');
        if (submitButton) {
            submitButton.disabled = false;
            submitButton.innerHTML = `
                <i class="fas fa-check me-2"></i>Konfirmasi Pengiriman
            `;
        }
    }
}

// Tambahkan event listener untuk menangani pemilihan bank
function handleCryptoBankSelection(bankChoices) {
    const otherBankContainer = document.getElementById('otherBankContainer');
    const otherBankInput = document.getElementById('otherBankName');
    const bankSelect = document.getElementById('bankSelect');

    // Event listener untuk perubahan pada dropdown bank
    bankChoices.passedElement.element.addEventListener('change', function(e) {
        const selectedValue = e.detail.value;
        console.log('Bank selected:', selectedValue);

        if (selectedValue === 'other') {
            otherBankContainer.style.display = 'block';
            otherBankInput.required = true;
        } else {
            otherBankContainer.style.display = 'none';
            otherBankInput.required = false;
            otherBankInput.value = '';
        }
    });
}

// Fungsi untuk update estimasi harga
async function updateEstimateDisplay() {
    try {
        const amount = document.getElementById('amount').value.replace(/[^\d]/g, '');
        const selectedCoin = document.getElementById('coin').value;
        const priceEstimate = document.getElementById('priceEstimate');
        const checkoutAmount = document.getElementById('checkoutAmount');
        
        if (!amount || !selectedCoin || !priceEstimate) {
            if (priceEstimate) priceEstimate.textContent = '-';
            if (checkoutAmount) checkoutAmount.textContent = '-';
            return;
        }

        // Show loading
        priceEstimate.innerHTML = `<span class="spinner-border spinner-border-sm"></span>`;

        // Fetch price from API
        const response = await fetch(`api/price_handler.php?symbol=${selectedCoin}`);
        const data = await response.json();

        if (data.success) {
            const estimatedIDR = amount * parseFloat(data.price_idr);
            
            // Update both displays with the same value
            priceEstimate.textContent = formatRupiah(estimatedIDR);
            if (checkoutAmount) {
                checkoutAmount.textContent = formatRupiah(estimatedIDR);
            }

            // Debug
            console.log('Estimate updated:', {
                amount,
                price: data.price_idr,
                estimatedIDR,
                formattedValue: formatRupiah(estimatedIDR)
            });
        }

    } catch (error) {
        console.error('Error updating estimate:', error);
        const priceEstimate = document.getElementById('priceEstimate');
        if (priceEstimate) priceEstimate.textContent = 'Error';
    }
}

// Fungsi untuk reset form
function resetForms() {
    const elements = [
        'amount',
        'coin',
        'network',
        'networkAddress',
        'networkMemo',
        'txHash',
        'bankSelect',
        'accountNumber',
        'accountName'
    ];

    elements.forEach(id => {
        const element = document.getElementById(id);
        if (element) element.value = '';
    });

    const displays = ['priceEstimate', 'checkoutAmount'];
    displays.forEach(id => {
        const element = document.getElementById(id);
        if (element) element.textContent = '-';
    });
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Input amount listener
    const amountInput = document.getElementById('amount');
    if (amountInput) {
        amountInput.addEventListener('input', () => {
            setTimeout(updateEstimateDisplay, 500);
        });
    }

    // Coin select listener
    const coinSelect = document.getElementById('coin');
    if (coinSelect) {
        coinSelect.addEventListener('change', updateEstimateDisplay);
    }

    // Submit button listener
    const submitBtn = document.getElementById('confirmSentBtn');
    if (submitBtn) {
        submitBtn.addEventListener('click', submitCryptoTransaction);
    }
});

function calculateAdminFee(amount, type) {
    // Fee structure untuk CV Crypto
    const cryptoFeeStructure = [
        { threshold: 1000000, fee: 5000 },
        { threshold: 5000000, fee: 10000 },
        { threshold: 10000000, fee: 15000 },
        { threshold: 50000000, fee: 25000 },
        { threshold: Infinity, fee: 50000 }
    ];

    // Fee structure untuk CV Exchange
    const exchangeFeeStructure = [
        { threshold: 1000000, fee: 3000 },
        { threshold: 5000000, fee: 7000 },
        { threshold: 10000000, fee: 12000 },
        { threshold: 50000000, fee: 20000 },
        { threshold: Infinity, fee: 35000 }
    ];

    const feeStructure = type === 'exchange' ? exchangeFeeStructure : cryptoFeeStructure;
    
    for (const tier of feeStructure) {
        if (amount <= tier.threshold) {
            return tier.fee;
        }
    }
    
    return feeStructure[feeStructure.length - 1].fee;
}

function copyAddress() {
    const addressInput = document.getElementById('networkAddress');
    addressInput.select();
    document.execCommand('copy');
    
    Toastify({
        text: "Alamat berhasil disalin!",
        duration: 3000,
        gravity: "top",
        position: "right",
        backgroundColor: "linear-gradient(to right, #00b09b, #96c93d)",
    }).showToast();
}

function copyMemo() {
    const memo = document.getElementById('networkMemo');
    memo.select();
    document.execCommand('copy');
    Toastify({
        text: "Note/Memo berhasil disalin!",
        duration: 3000,
        gravity: "top",
        position: "right",
        backgroundColor: "linear-gradient(to right, #00b09b, #96c93d)",
    }).showToast();
}

// Network Details Update
function updateNetworkDetails(coin, network) {
    console.log('Function called with:', coin, network); // Debug

    const networkKey = network.toLowerCase().replace(/\s+/g, '_');
    console.log('Network key:', networkKey); // Debug

    const addressData = {
        'aptos_network': {
            address: 'apt1234567890abcdef',
            qr: 'https://api.qrserver.com/v1/create-qr-code/?data=apt1234567890abcdef',
            memo: '123553',
        },
        'bnb_beacon_chain_(bep2)': {
            address: 'bnb1234567890abcdef',
            qr: 'https://api.qrserver.com/v1/create-qr-code/?data=bnb1234567890abcdef',
            memo: 'Tidak diperlukan'
        }
    };

    console.log('Address data:', addressData[networkKey]); // Debug

    const networkData = addressData[networkKey] || {
        address: 'Address belum tersedia',
        qr: 'https://api.qrserver.com/v1/create-qr-code/?data=not_available',
        memo: 'Tidak diperlukan'
    };

    console.log('Network data:', networkData); // Debug

    document.getElementById('networkQR').src = networkData.qr;
    document.getElementById('networkAddress').value = networkData.address;
    document.getElementById('networkMemo').value = networkData.memo;
    console.log('Memo value set to:', networkData.memo); // Debug

    document.querySelector('.network-info-container').style.display = 'block';
}

function copyExchangeAddress() {
    const addressInput = document.getElementById('exchangeAddress');
    addressInput.select();
    document.execCommand('copy');
    
    Toastify({
        text: "ID/Email berhasil disalin!",
        duration: 3000,
        gravity: "top",
        position: "right",
        backgroundColor: "linear-gradient(to right, #00b09b, #96c93d)",
    }).showToast();
}

// Update event listeners untuk form exchange
function setupExchangeFormValidation() {
    const formElements = [
        'exchangeAmount',
        'exchangeProofImage',
        'exchangeBankSelect',
        'exchangeOtherBankName',
        'exchangeAccountNumber',
        'exchangeAccountName'
    ];

    formElements.forEach(elementId => {
        const element = document.getElementById(elementId);
        if (element) {
            element.addEventListener('input', validateExchangeForm);
            element.addEventListener('change', validateExchangeForm);
        }
    });

    // Add submit button event listener
    const submitButton = document.getElementById('exchangeConfirmSentBtn');
    if (submitButton) {
        submitButton.addEventListener('click', function(e) {
            e.preventDefault();
            submitExchangeTransaction();
        });
    }
}

// Fungsi untuk mengambil nilai estimasi dengan benar
function getCleanEstimatedAmount() {
    const priceEstimateElement = document.getElementById('priceEstimate'); // ID yang benar
    if (!priceEstimateElement) {
        console.error('Price estimate element not found');
        return '0';
    }
    
    // Debug raw value
    console.log('Raw estimate:', priceEstimateElement.textContent);
    
    // Bersihkan dari semua karakter non-angka
    let cleanValue = priceEstimateElement.textContent
        .replace(/[^0-9]/g, '');
    
    // Debug clean value
    console.log('Clean estimate:', cleanValue);
    
    return cleanValue || '0';
}

// Fungsi untuk menangani pemilihan bank
function handleBankSelection(bankChoices) {
    const otherBankContainer = document.getElementById('otherBankContainer');
    const otherBankInput = document.getElementById('exchangeOtherBankName');
    const bankSelect = document.getElementById('exchangeBankSelect');

    // Event listener untuk perubahan pada dropdown bank
    bankChoices.passedElement.element.addEventListener('change', function(e) {
        const selectedValue = e.detail.value;
        console.log('Bank selected:', selectedValue);

        if (selectedValue === 'OTHER') {
            otherBankContainer.style.display = 'block';
            otherBankInput.required = true;
            
            // Ketika OTHER dipilih, update value bankSelect dengan nilai dari otherBankInput
            otherBankInput.addEventListener('input', function() {
                bankSelect.value = this.value; // Set value bankSelect ke nilai yang diketik
                console.log('Bank value updated:', bankSelect.value);
            });
        } else {
            otherBankContainer.style.display = 'none';
            otherBankInput.required = false;
            otherBankInput.value = '';
        }
    });
}

// Update fungsi submit
async function submitExchangeTransaction() {
    const submitButton = document.getElementById('exchangeConfirmSentBtn');
    submitButton.disabled = true;
    submitButton.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span>Memproses...`;

    try {
        // Ambil semua elemen form termasuk bukti transfer
        const amount = document.getElementById('exchangeAmount');
        const exchange = document.getElementById('exchangeSelect');
        const currency = document.getElementById('currency');
        const bankSelect = document.getElementById('exchangeBankSelect');
        const exchangeOtherBankName = document.getElementById('exchangeOtherBankName');
        const accountNumber = document.getElementById('exchangeAccountNumber');
        const accountName = document.getElementById('exchangeAccountName');
        const priceEstimate = document.getElementById('exchangePriceEstimate');
        const checkoutFee = document.getElementById('exchangeCheckoutFee');
        const checkoutTotal = document.getElementById('exchangeCheckoutTotal');
        const proofImage = document.getElementById('exchangeProofImage');

        // Validasi keberadaan elemen
        if (!amount || !exchange || !currency || !bankSelect || 
            !accountNumber || !accountName || !priceEstimate || 
            !checkoutFee || !checkoutTotal || !proofImage) {
            throw new Error('Beberapa elemen form tidak ditemukan');
        }

        // Validasi bukti transfer
        if (!proofImage.files || !proofImage.files[0]) {
            throw new Error('Mohon upload bukti transfer');
        }

        // Tentukan bank_type dengan pengecekan
        let bankType;
        if (bankSelect.value === 'other') {
            if (!exchangeOtherBankName || !exchangeOtherBankName.value) {
                throw new Error('Mohon masukkan nama bank');
            }
            bankType = exchangeOtherBankName.value;
            console.log('Using other bank name:', bankType);
        } else {
            bankType = bankSelect.value;
            console.log('Using selected bank:', bankType);
        }

        // Proses nilai-nilai numerik dengan pengecekan
        let estimatedAmount = priceEstimate.textContent || '0';
        estimatedAmount = estimatedAmount.replace(/[^0-9,]/g, '').split(',')[0];

        let adminFee = checkoutFee.textContent || '0';
        adminFee = adminFee.replace(/[^0-9,]/g, '').split(',')[0];

        let totalAmount = checkoutTotal.textContent || '0';
        totalAmount = totalAmount.replace(/[^0-9,]/g, '').split(',')[0];

        // Buat FormData dengan pengecekan nilai
        const formData = new FormData();
        formData.append('type', 'exchange');
        formData.append('amount', amount.value || '');
        formData.append('exchange', exchange.value || '');
        formData.append('currency', currency.value || '');
        formData.append('estimated_amount', estimatedAmount);
        formData.append('admin_fee', adminFee);
        formData.append('total_amount', totalAmount);
        formData.append('bank_type', bankType);
        formData.append('account_number', accountNumber.value || '');
        formData.append('account_name', accountName.value || '');
        formData.append('proof_image', proofImage.files[0]);

        // Debug log
        console.log('Form data being submitted:', {
            type: 'exchange',
            amount: amount.value,
            exchange: exchange.value,
            currency: currency.value,
            estimated_amount: estimatedAmount,
            admin_fee: adminFee,
            total_amount: totalAmount,
            bank_type: bankType,
            account_number: accountNumber.value,
            account_name: accountName.value,
            proof_image: proofImage.files[0].name
        });

        // Validasi data sebelum kirim
        if (!amount.value || !exchange.value || !currency.value || 
            !bankType || !accountNumber.value || !accountName.value || 
            !proofImage.files[0]) {
            throw new Error('Mohon lengkapi semua field yang diperlukan');
        }

        // Kirim data ke server
        const response = await fetch('api/process_transaction.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (result.success) {
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Transaksi CV Exchange Anda telah berhasil diproses.',
                allowOutsideClick: false,
                allowEscapeKey: false,
                confirmButtonText: 'OK'
            }).then(() => {
                window.location.reload();
            });
        } else {
            throw new Error(result.message || 'Terjadi kesalahan saat memproses transaksi.');
        }

    } catch (error) {
        console.error('Error submitting exchange transaction:', error);
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: error.message || 'Terjadi kesalahan saat memproses transaksi.',
            confirmButtonText: 'OK'
        });
    } finally {
        submitButton.disabled = false;
        submitButton.innerHTML = `<i class="fas fa-check me-2"></i>Konfirmasi Pengiriman`;
    }
}

// Tambahkan event listener untuk preview image
document.getElementById('exchangeProofImage').addEventListener('change', function(e) {
    const preview = document.getElementById('exchangeImagePreview');
    const previewImg = preview.querySelector('img');
    const file = e.target.files[0];

    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            preview.style.display = 'block';
        }
        reader.readAsDataURL(file);
    } else {
        preview.style.display = 'none';
        previewImg.src = '';
    }
});

// Fungsi untuk reset form exchange
function resetExchangeForms() {
    // Reset selects
    if (exchangeChoices) exchangeChoices.setChoiceByValue('');
    if (currencyChoices) currencyChoices.setChoiceByValue('');
    if (exchangeBankChoices) exchangeBankChoices.setChoiceByValue('');

    // Reset inputs
    document.getElementById('exchangeAmount').value = '';
    document.getElementById('exchangeAccountNumber').value = '';
    document.getElementById('exchangeAccountName').value = '';
    document.getElementById('exchangeProofImage').value = '';

    // Reset displays
    document.getElementById('exchangePriceEstimate').textContent = '-';
    document.getElementById('exchangeCheckoutAmount').textContent = '-';
    document.getElementById('exchangeCheckoutFee').textContent = '-';
    document.getElementById('exchangeCheckoutTotal').textContent = '-';
    
    // Hide containers
    document.getElementById('exchangeCheckoutDetails').style.display = 'none';
    document.getElementById('exchangeImagePreview').style.display = 'none';
}

async function loadTransactionHistory() {
    try {
        const response = await fetch('api/get_transaction_history.php');
        const transactions = await response.json();
        
        const tbody = document.getElementById('transactionHistory');
        tbody.innerHTML = '';
        
        transactions.forEach(tx => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${tx.id}</td>
                <td><span class="badge ${getStatusBadgeClass(tx.status)}">${getStatusText(tx.status)}</span></td>
                <td>${formatRupiah(tx.amount)}</td>
                <td>${formatDate(tx.created_at)}</td>
            `;
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error('Error loading transaction history:', error);
    }
}

function getStatusBadgeClass(status) {
    const classMap = {
        'pending': 'bg-warning',
        'success': 'bg-success',
        'cancelled': 'bg-danger'
    };
    return classMap[status] || 'bg-secondary';
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('id-ID', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Load transaction history when page loads
document.addEventListener('DOMContentLoaded', loadTransactionHistory);

// Tambahkan loading indicator
function updateLoadingState(isLoading) {
    const priceDisplay = document.getElementById('price_display');
    if (isLoading) {
        priceDisplay.innerHTML += ' <span class="spinner-border spinner-border-sm"></span>';
    } else {
        priceDisplay.querySelector('.spinner-border')?.remove();
    }
}

// Fungsi untuk reset semua form
function resetAllForms() {
    // Reset nilai input
    document.querySelector('select[name="coin"]').value = '';
    document.querySelector('input[name="amount"]').value = '';
    document.querySelector('input[name="network"]').value = '';
    document.querySelector('input[name="tx_hash"]').value = '';
    document.querySelector('input[name="bank_type"]').value = '';
    document.querySelector('input[name="account_number"]').value = '';
    document.querySelector('input[name="account_name"]').value = '';
    document.getElementById('estimated_amount').value = '';
    document.getElementById('admin_fee').value = '';
    document.getElementById('total_amount').value = '';
    
    // Reset file input jika ada
    const fileInput = document.querySelector('input[type="file"]');
    if (fileInput) {
        fileInput.value = '';
    }

    // Reset price display
    document.getElementById('price_display').textContent = 'Select a coin to see current price';
    
    // Reset preview image jika ada
    const imagePreview = document.getElementById('image_preview');
    if (imagePreview) {
        imagePreview.style.display = 'none';
        imagePreview.src = '';
    }

    // Stop price updates
    stopPriceUpdate();
}

// Fungsi untuk reset form spesifik step
function resetStepForm(stepNumber) {
    switch(stepNumber) {
        case 1:
            // Reset form step 1 (Pilih Coin)
            document.querySelector('select[name="coin"]').value = '';
            document.querySelector('input[name="amount"]').value = '';
            document.getElementById('estimated_amount').value = '';
            document.getElementById('price_display').textContent = 'Select a coin to see current price';
            stopPriceUpdate();
            break;
            
        case 2:
            // Reset form step 2 (Network & Transaction Hash)
            document.querySelector('input[name="network"]').value = '';
            document.querySelector('input[name="tx_hash"]').value = '';
            break;
            
        case 3:
            // Reset form step 3 (Bank Details)
            document.querySelector('input[name="bank_type"]').value = '';
            document.querySelector('input[name="account_number"]').value = '';
            document.querySelector('input[name="account_name"]').value = '';
            break;
            
        case 4:
            // Reset form step 4 (Upload Bukti)
            const fileInput = document.querySelector('input[type="file"]');
            if (fileInput) fileInput.value = '';
            const imagePreview = document.getElementById('image_preview');
            if (imagePreview) {
                imagePreview.style.display = 'none';
                imagePreview.src = '';
            }
            break;
    }
}

// Event listener untuk tombol close/cancel di setiap step
document.querySelectorAll('.btn-close, .btn-cancel').forEach(button => {
    button.addEventListener('click', function() {
        const stepNumber = parseInt(this.closest('.step').dataset.step);
        resetStepForm(stepNumber);
    });
});

// Reset form setelah transaksi berhasil
function handleSuccessTransaction() {
    resetAllForms();
    // Tampilkan pesan sukses
    Swal.fire({
        icon: 'success',
        title: 'Transaksi Berhasil',
        text: 'Terima kasih, transaksi Anda sedang diproses',
        confirmButtonText: 'OK'
    }).then((result) => {
        // Redirect ke halaman utama atau refresh halaman
        if (result.isConfirmed) {
            window.location.href = 'index.php';
        }
    });
}

// Event listener saat user meninggalkan halaman
window.addEventListener('beforeunload', function() {
    resetAllForms();
    stopPriceUpdate();
});

// Event listener untuk navigasi antar step
document.querySelectorAll('.step-nav').forEach(button => {
    button.addEventListener('click', function() {
        const currentStep = parseInt(this.closest('.step').dataset.step);
        const nextStep = this.classList.contains('next') ? currentStep + 1 : currentStep - 1;
        
        // Reset form jika navigasi ke step sebelumnya
        if (!this.classList.contains('next')) {
            resetStepForm(currentStep);
        }
    });
});
// Tambahkan fungsi untuk update placeholder
function updateAmountPlaceholder(coin) {
    const amountInput = document.getElementById('amount');
    amountInput.placeholder = `Masukkan jumlah ${coin}`;
}
</script>
</body>
</html>
</html>

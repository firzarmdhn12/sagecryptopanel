-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 04, 2024 at 05:11 PM
-- Server version: 10.11.9-MariaDB-cll-lve
-- PHP Version: 8.3.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sagd9981_sagecrypto`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_accounts`
--

CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL,
  `payment_type` enum('bank','ewallet') NOT NULL DEFAULT 'bank',
  `bank_type` varchar(50) NOT NULL,
  `account_number` varchar(50) NOT NULL,
  `account_name` varchar(100) NOT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `bank_accounts`
--

INSERT INTO `bank_accounts` (`id`, `payment_type`, `bank_type`, `account_number`, `account_name`, `qr_code`, `logo`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'bank', 'bca', '1234567890', 'JOHN DOE', NULL, NULL, 'Transfer melalui BCA', 'active', '2024-11-04 16:47:00', '2024-11-04 16:47:00'),
(2, 'bank', 'mandiri', '0987654321', 'JOHN DOE', NULL, NULL, 'Transfer melalui Mandiri', 'active', '2024-11-04 16:47:00', '2024-11-04 16:47:00'),
(3, 'bank', 'bni', '1122334455', 'JOHN DOE', NULL, NULL, 'Transfer melalui BNI', 'active', '2024-11-04 16:47:00', '2024-11-04 16:47:00'),
(4, 'bank', 'bri', '9988776655', 'JOHN DOE', NULL, NULL, 'Transfer melalui BRI', 'active', '2024-11-04 16:47:00', '2024-11-04 16:47:00'),
(5, 'ewallet', 'ovo', '081234567890', 'JOHN DOE', NULL, NULL, 'Pembayaran melalui OVO', 'active', '2024-11-04 16:47:00', '2024-11-04 16:47:00'),
(6, 'ewallet', 'gopay', '081234567890', 'JOHN DOE', NULL, NULL, 'Pembayaran melalui GoPay', 'active', '2024-11-04 16:47:00', '2024-11-04 16:47:00'),
(7, 'ewallet', 'dana', '081234567890', 'JOHN DOE', NULL, NULL, 'Pembayaran melalui DANA', 'active', '2024-11-04 16:47:00', '2024-11-04 16:47:00'),
(8, 'ewallet', 'shopeepay', '081234567890', 'JOHN DOE', NULL, NULL, 'Pembayaran melalui ShopeePay', 'active', '2024-11-04 16:47:00', '2024-11-04 16:47:00');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `transaction_fee` decimal(5,2) NOT NULL DEFAULT 2.50,
  `min_transaction` decimal(15,2) NOT NULL DEFAULT 100000.00,
  `max_transaction` decimal(15,2) NOT NULL DEFAULT 100000000.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `transaction_fee`, `min_transaction`, `max_transaction`, `created_at`, `updated_at`) VALUES
(1, 2.50, 100000.00, 100000000.00, '2024-11-04 10:44:47', '2024-11-04 10:44:47');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `type` enum('crypto','exchange') NOT NULL,
  `coin` varchar(50) DEFAULT NULL,
  `network` varchar(50) DEFAULT NULL,
  `tx_hash` text DEFAULT NULL,
  `exchange` varchar(50) DEFAULT NULL,
  `currency` varchar(50) DEFAULT NULL,
  `amount` decimal(65,8) DEFAULT NULL,
  `estimated_amount` decimal(20,2) NOT NULL DEFAULT 0.00,
  `admin_fee` decimal(20,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(20,2) NOT NULL DEFAULT 0.00,
  `bank_type` varchar(50) NOT NULL,
  `other_bank_name` varchar(100) DEFAULT NULL,
  `account_number` varchar(50) NOT NULL,
  `account_name` varchar(100) NOT NULL,
  `proof_image` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('pending','success','cancelled') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `type`, `coin`, `network`, `tx_hash`, `exchange`, `currency`, `amount`, `estimated_amount`, `admin_fee`, `total_amount`, `bank_type`, `other_bank_name`, `account_number`, `account_name`, `proof_image`, `notes`, `status`, `created_at`, `updated_at`) VALUES
(7, 'crypto', 'BTC', 'Lightning Network', 'adssad', NULL, NULL, 0.00300000, 3254852.00, 10000.00, 3244852.00, 'bni', '', '2333', 'sdaasd', '', '', 'pending', '2024-11-04 10:05:52', '2024-11-04 10:05:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
require_once 'config/database.php';

try {
    // Tabel settings
    $db->exec("CREATE TABLE IF NOT EXISTS settings (
        id INT PRIMARY KEY AUTO_INCREMENT,
        transaction_fee DECIMAL(5,2) DEFAULT 0.00,
        min_transaction DECIMAL(15,2) DEFAULT 0.00,
        max_transaction DECIMAL(15,2) DEFAULT 0.00,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");

    // Tabel bank_accounts
    $db->exec("CREATE TABLE IF NOT EXISTS bank_accounts (
        id INT PRIMARY KEY AUTO_INCREMENT,
        bank_type VARCHAR(50) NOT NULL,
        account_number VARCHAR(50) NOT NULL,
        account_name VARCHAR(100) NOT NULL,
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");

    // Tabel transactions
    $db->exec("CREATE TABLE IF NOT EXISTS transactions (
        id INT PRIMARY KEY AUTO_INCREMENT,
        type ENUM('crypto', 'exchange') NOT NULL,
        amount DECIMAL(15,2) NOT NULL,
        fee DECIMAL(15,2) DEFAULT 0.00,
        status ENUM('pending', 'success', 'cancelled') DEFAULT 'pending',
        account_name VARCHAR(100) NOT NULL,
        account_number VARCHAR(50) NOT NULL,
        bank_type VARCHAR(50) NOT NULL,
        proof_image VARCHAR(255),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");

    // Insert default settings
    $db->exec("INSERT INTO settings (transaction_fee, min_transaction, max_transaction) 
               VALUES (2.5, 100000, 100000000)
               ON DUPLICATE KEY UPDATE id=id");
               

    echo "Database tables created successfully!";
} catch(PDOException $e) {
    echo "Error creating tables: " . $e->getMessage();
}
?>